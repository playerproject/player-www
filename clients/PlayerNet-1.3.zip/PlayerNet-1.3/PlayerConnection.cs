//=========================================================
// Filename: PlayerConnection.cs
//
// Copyright (c) 2003 Applied Research Laboratory 
//                The Pennsylvania State University
//
// Purpose: Implements all details of the Player message
//			passing.
//
// Date Created: 01/27/2003
// Author:		 Jason K. Douglas
//
// MODIFICATION HISTORY:
//   DATE        SPR    INITIALS  DESCRIPTION
//   ----        ---    --------  --------------------------- 
//   01/27/03    000      jkd     First release
//	 02/28/03	 000	  jkd	  Added a destructor to disconnect
//
//=========================================================

using System;
using System.Diagnostics;
using System.Net;
using System.Net.Sockets;
using System.Text;
using PlayerNet.Messages;

namespace PlayerNet
{
	/// <summary>
	/// Summary description for PlayerConnection.
	/// </summary>
	public class PlayerConnection
	{
		public const int PLAYER_MAX_MESSAGE_SIZE = 8192;
		public const int PLAYER_IDENT_STRLEN = 32;
		public const int PLAYER_MAX_DEVICE_STRING_LEN = 64;

		public const short PLAYER_STXX = 0x5878;

		public const short PLAYER_MSGTYPE_DATA = 1;
		public const short PLAYER_MSGTYPE_CMD = 2;
		public const short PLAYER_MSGTYPE_REQ = 3;
		public const short PLAYER_MSGTYPE_RESP_ACK = 4;
		public const short PLAYER_MSGTYPE_SYNCH = 5;
		public const short PLAYER_MSGTYPE_RESP_NACK = 6;
		public const short PLAYER_MSGTYPE_RESP_ERR = 7;

		public const short PLAYER_PLAYER_CODE = 1;
		public const short PLAYER_MISC_CODE = 2;
		public const short PLAYER_GRIPPER_CODE = 3;  
		public const short PLAYER_POSITION_CODE = 4;
		public const short PLAYER_SONAR_CODE = 5;
		public const short PLAYER_LASER_CODE = 6; 
		public const short PLAYER_VISION_CODE = 7; 
		public const short PLAYER_PTZ_CODE = 8;
		public const short PLAYER_AUDIO_CODE = 9;
		public const short PLAYER_LASERBEACON_CODE = 10;
		public const short PLAYER_BROADCAST_CODE = 11;
		public const short PLAYER_SPEECH_CODE = 12;
		public const short PLAYER_GPS_CODE = 13;
		public const short PLAYER_OCCUPANCY_CODE = 14;
		public const short PLAYER_TRUTH_CODE = 15;
		public const short PLAYER_BPS_CODE = 16;

		public const short PLAYER_PLAYER_DEVLIST_REQ = 1;
		public const short PLAYER_PLAYER_DRIVERINFO_REQ = 2;
		public const short PLAYER_PLAYER_DEV_REQ = 3;
		public const short PLAYER_PLAYER_DATA_REQ = 4;
		public const short PLAYER_PLAYER_DATAMODE_REQ = 5;
		public const short PLAYER_PLAYER_DATAFREQ_REQ = 6;
		public const short PLAYER_PLAYER_AUTH_REQ = 7;

		public PlayerConnection()
		{
		}

		~PlayerConnection()
		{
			Disconnect();
		}

		public bool Connected
		{
			get { return mySocket != null; }
		}

		public string Banner
		{
			get { return myBanner; }
		}

		public string Hostname
		{
			get { return myHostname; }
		}

		public int Port
		{
			get { return myPort; }
		}

		private TcpClient mySocket;
		private string myBanner;
		private string myHostname;
		private int myPort;

		public void Connect(string hostname, int port)
		{
			try
			{
				mySocket = new TcpClient(hostname, port);
				mySocket.NoDelay = false;

				NetworkStream ns = mySocket.GetStream();
				byte[] buffer = new byte[PLAYER_IDENT_STRLEN];
				ns.Read(buffer, 0, (int)PLAYER_IDENT_STRLEN);

				ASCIIEncoding ae = new ASCIIEncoding();
				myBanner = ae.GetString(buffer);

				myHostname = hostname;
				myPort = port;
			}
			catch (Exception)
			{
				mySocket = null;
			}
		}

		public void Connect(string hostname)
		{
			Connect(hostname, 6665);
		}

		public void Connect()
		{
			Connect("localhost");
		}

		public void Disconnect()
		{
			//Trace.WriteLine("Disconnecting PlayerConnection");

			if (mySocket != null)
			{
				mySocket.Close();
				mySocket = null;
			}
		}

		public void Write(short device, short index, byte[] data)
		{
			Write(device, index, data, PLAYER_MSGTYPE_CMD);
		}

		public void Write(short device, short index, byte[] data, short msgType)
		{
			// Can't write, if we're not connected
			if (!Connected)
				return;

			unsafe
			{
				if (data.Length > PLAYER_MAX_MESSAGE_SIZE - sizeof(PlayerMsgHdr))
					throw new ArgumentOutOfRangeException("data.Length", data.Length, "Message payload too big.");
			}

			// Fill in the header structure with the appropriate data
			PlayerMsgHdr hdr;
			hdr.stx = IPAddress.HostToNetworkOrder(PLAYER_STXX);
			hdr.type = IPAddress.HostToNetworkOrder(msgType);
			hdr.device = IPAddress.HostToNetworkOrder(device);
			hdr.device_index = IPAddress.HostToNetworkOrder(index);
			hdr.time_sec = 0;
			hdr.time_usec = 0;
			hdr.timestamp_sec = 0;
			hdr.timestamp_usec = 0;
			hdr.reserved = 0;
			hdr.size = IPAddress.HostToNetworkOrder(data.Length);

			// We need an unsafe code block to copy the header and payload data to a buffer
			byte[] buffer;
			unsafe
			{
				buffer = new byte[sizeof(PlayerMsgHdr) + data.Length];
				byte* pHdr = (byte*)&hdr;
				for (int i = 0; i < sizeof(PlayerMsgHdr); i++, pHdr++)
					buffer[i] = *pHdr;

				for (int i = 0; i < data.Length; i++)
					buffer[i + sizeof(PlayerMsgHdr)] = data[i];
			}

			// Write the buffered data to the connection
			NetworkStream ns = mySocket.GetStream();
			ns.Write(buffer, 0, buffer.Length);
		}

		public void Read(ref PlayerMsgHdr hdr, ref byte[] data)
		{
			// Can't read, if we're not connected
			if (!Connected)
				return;

			NetworkStream ns = mySocket.GetStream();

			// Read bytes until we receive an STXX (start bytes)
			byte[] buffer;
			int bytesRead = 0;
			hdr.stx = 0;
			while (hdr.stx != PLAYER_STXX)
			{
				unsafe
				{
					buffer = new byte[sizeof(short)];
				}
				bytesRead = ns.Read(buffer, 0, buffer.Length);

				hdr.stx = BitConverter.ToInt16(buffer, 0); 
				hdr.stx = IPAddress.NetworkToHostOrder(hdr.stx);
			}

			// Calculate the number of bytes remaining to be read for the header
			int bytesLeftInHeader;
			unsafe
			{
				bytesLeftInHeader = sizeof(PlayerMsgHdr) - 2;
			}

			// Read the remaining part of the header
			buffer = new byte[bytesLeftInHeader + bytesRead];
			bytesRead += ns.Read(buffer, bytesRead, buffer.Length - bytesRead);

			// Parse the header structure from the buffer
			unsafe
			{
				fixed (byte* fixedBuffer = buffer)
				{
					PlayerMsgHdr* newHeader = (PlayerMsgHdr*)fixedBuffer;
					hdr.type = IPAddress.NetworkToHostOrder(newHeader->type);
					hdr.device = IPAddress.NetworkToHostOrder(newHeader->device);
					hdr.device_index = IPAddress.NetworkToHostOrder(newHeader->device_index);
					hdr.time_sec = IPAddress.NetworkToHostOrder(newHeader->time_sec);
					hdr.time_usec = IPAddress.NetworkToHostOrder(newHeader->time_usec);
					hdr.timestamp_sec = IPAddress.NetworkToHostOrder(newHeader->timestamp_sec);
					hdr.timestamp_usec = IPAddress.NetworkToHostOrder(newHeader->timestamp_usec);
					hdr.size = IPAddress.NetworkToHostOrder(newHeader->size);
				}
			}

			// Check for overly large messages
			if (hdr.size >= PLAYER_MAX_MESSAGE_SIZE)
			{
				throw new ArgumentOutOfRangeException("PlayerMsgHdr.size", hdr.size, "Server's message is too big.");
			}

			// Read the message payload
			data = new byte[hdr.size];
			if (hdr.size > 0)
				ns.Read(data, 0, data.Length);
		}

		public void Request(short device, short index, byte[] data)
		{
			// Can't request, if we're not connected
			if (!Connected)
				return;

			// Write the request data
			Write(device, index, data, PLAYER_MSGTYPE_REQ);
		}

		public void Request(short device, short index, byte[] data, ref PlayerMsgHdr replyHdr, ref byte[] replyData)
		{
			// Send the request
			Request(device, index, data);

			// Eat data until a response comes back
			replyHdr.type = 0;
			replyHdr.device = 0;
			replyHdr.device_index = 0;
			while (replyHdr.type != PLAYER_MSGTYPE_RESP_ACK ||
				replyHdr.device != device ||
				replyHdr.device_index != index)
			{
				// Read the next packet
				Read(ref replyHdr, ref replyData);
			}
		}

		public char RequestDeviceAccess(short device, short index,	char requestedAccess)
		{
			// Can't request device access, if we're not connected
			if (!Connected)
				return 'e';

			// Setup a packet to request device access
			PlayerDeviceReq req;
			req.subtype = (ushort)IPAddress.HostToNetworkOrder(PLAYER_PLAYER_DEV_REQ);
			req.code = (ushort)IPAddress.HostToNetworkOrder(device);
			req.index = (ushort)IPAddress.HostToNetworkOrder(index);
			req.access = BitConverter.GetBytes(requestedAccess)[0];

			// Convert packet into a byte buffer
			byte[] data;
			unsafe
			{
				data = new byte[sizeof(PlayerDeviceReq)];
				byte* pReq = (byte*)&req;
				for (int i = 0; i < sizeof(PlayerDeviceReq); i++, pReq++)
					data[i] = *pReq;
			}

			// Send request for the device and read the reply
			PlayerMsgHdr replyHdr = new PlayerMsgHdr();
			byte[] replyData = null;
			Request(PLAYER_PLAYER_CODE, 0, data, ref replyHdr, ref replyData);

			// The reply will look similar to the request, with a device string
			PlayerDeviceResp replyResp;

			// Decode the reply and see what access was granted for the device
			unsafe
			{
				fixed (byte* fixedData = replyData)
				{
					PlayerDeviceResp* pResp = (PlayerDeviceResp*)(fixedData);
					replyResp.subtype = (ushort)IPAddress.NetworkToHostOrder(pResp->subtype);
					replyResp.access = pResp->access;
					replyResp.code = (ushort)IPAddress.NetworkToHostOrder(pResp->code);
					replyResp.index = (ushort)IPAddress.NetworkToHostOrder(pResp->index);
				}

				//string strDevice = new ASCIIEncoding().GetString(replyData, sizeof(PlayerDeviceResp) - PLAYER_MAX_DEVICE_STRING_LEN, PLAYER_MAX_DEVICE_STRING_LEN - 1);
				//Trace.WriteLine("Access to (" + replyResp.code + ":" + replyResp.index + ") = " + (char)replyResp.access);
			}

			// Return the access granted to the caller
			return (char)replyResp.access;
		}
	}
}
