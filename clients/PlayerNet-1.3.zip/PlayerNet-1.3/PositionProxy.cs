//=========================================================
// Filename: PositionProxy.cs
//
// Copyright (c) 2003 Applied Research Laboratory 
//                The Pennsylvania State University
//
// Purpose: Client proxy for moving the robot and tracking
//			its relative position.
//
// Date Created: 01/27/2003
// Author:		 Jason K. Douglas
//
// MODIFICATION HISTORY:
//   DATE        SPR    INITIALS  DESCRIPTION
//   ----        ---    --------  --------------------------- 
//   01/27/03    000      jkd     First release
//
//=========================================================

using System;
using System.Net;
using System.Diagnostics;
using PlayerNet.Messages;

namespace PlayerNet
{
	/// <summary>
	/// 
	/// </summary>
	public class PositionProxy : PlayerNet.ClientProxy
	{
		private readonly byte PLAYER_POSITION_GET_GEOM_REQ = 1;
		private readonly byte PLAYER_POSITION_MOTOR_POWER_REQ = 2;
		private readonly byte PLAYER_POSITION_VELOCITY_CONTROL_REQ = 3;
		private readonly byte PLAYER_POSITION_RESET_ODOM_REQ = 4;

		private int myXPos = 0;
		private int myYPos = 0;
		private int myTheta = 0;
		private int mySpeed = 0;
		private int mySideSpeed = 0;
		private int myTurnRate = 0;
		private byte myStalls = 0;
		private bool myMotorsEnabled = false;
		private byte myVelocityControl = 0;

		private object mySync = "PositionProxy sync";

		public int XPos
		{
			get { lock (mySync) { return myXPos; } }
		}

		public int YPos
		{
			get { lock (mySync) { return myYPos; } }
		}

		public int Theta
		{
			get { lock (mySync) { return myTheta; } }
		}

		public int Speed
		{
			get { lock (mySync) { return mySpeed; } }
			set
			{
				lock (mySync)
				{
					if (mySpeed != value)
					{
						mySpeed = value;
						UpdateSpeeds();
					}
				}
			}
		}

		public int SideSpeed
		{
			get { lock (mySync) { return mySideSpeed; } }
			set
			{
				lock (mySync)
				{
					if (mySideSpeed != value)
					{
						mySideSpeed = value;
						UpdateSpeeds();
					}
				}
			}
		}

		public int TurnRate
		{
			get { lock (mySync) { return myTurnRate; } }
			set
			{
				lock (mySync)
				{
					if (myTurnRate != value)
					{
						myTurnRate = value;
						UpdateSpeeds();
					}
				}
			}
		}

		public byte Stalls
		{
			get { lock (mySync) { return myStalls; } }
		}

		public bool MotorsEnabled
		{
			get { lock (mySync) { return myMotorsEnabled; } }
			set
			{
				lock (mySync)
				{
					myMotorsEnabled = value;

					byte motors = myMotorsEnabled?(byte)1:(byte)0;
					Client.Request(PlayerConnection.PLAYER_POSITION_CODE, Index, new byte[]{PLAYER_POSITION_MOTOR_POWER_REQ, motors});
				}
			}
		}

		public byte VelocityControl
		{
			get { lock (mySync) { return myVelocityControl; } }
			set
			{
				lock (mySync)
				{
					myVelocityControl = value;
					Client.Write(PlayerConnection.PLAYER_POSITION_CODE, Index, new byte[]{PLAYER_POSITION_VELOCITY_CONTROL_REQ, myVelocityControl});
				}
			}
		}

		public PositionProxy(PlayerClient pc) : this(pc, 0)
		{
		}

		public PositionProxy(PlayerClient pc, short index) : this(pc, index, 'a')
		{
		}

		public PositionProxy(PlayerClient pc, short index, char access) : base(pc, PlayerConnection.PLAYER_POSITION_CODE, index, access)
		{
		}

		public override void FillData(PlayerMsgHdr hdr, byte[] data)
		{
			unsafe
			{
				fixed (byte* pData = data)
				{
					PlayerPositionData* pos = (PlayerPositionData*)pData;

					lock (mySync)
					{
						myXPos = IPAddress.NetworkToHostOrder(pos->xpos);
						myYPos = IPAddress.NetworkToHostOrder(pos->ypos);
						myTheta = IPAddress.NetworkToHostOrder(pos->yaw);
						mySpeed = IPAddress.NetworkToHostOrder(pos->xspeed);
						mySideSpeed = IPAddress.NetworkToHostOrder(pos->yspeed);
						myTurnRate = IPAddress.NetworkToHostOrder(pos->yawspeed);
						myStalls = pos->stall;
					}
				}
			}
		}

		public void ResetOdometry()
		{
			Client.Write(Device, Index, new byte[]{PLAYER_POSITION_RESET_ODOM_REQ});
		}

		private void UpdateSpeeds()
		{
			// Fill in a packet to upload the new speed to the robot
			PlayerPositionCommand cmd;
			cmd.xpos = 0;
			cmd.ypos = 0;
			cmd.yaw = 0;
			cmd.xspeed = IPAddress.HostToNetworkOrder(Speed);
			cmd.yspeed = IPAddress.HostToNetworkOrder(SideSpeed);
			cmd.yawspeed = IPAddress.HostToNetworkOrder(TurnRate);

			// Convert packet to a byte buffer
			byte[] data;
			unsafe
			{
				data = new byte[sizeof(PlayerPositionCommand)];
				byte* pCmd = (byte*)&cmd;
				for (int i = 0; i < sizeof(PlayerPositionCommand); i++, pCmd++)
					data[i] = *pCmd;
			}

			// Write the packet to the robot
			Client.Write(Device, Index, data);
		}
	}
}
