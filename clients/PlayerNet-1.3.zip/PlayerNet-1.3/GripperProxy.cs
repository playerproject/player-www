//=========================================================
// Filename: GripperProxy.cs
//
// Copyright (c) 2003 Applied Research Laboratory 
//                The Pennsylvania State University
//
// Purpose: Client proxy for commanding a gripper arm.
//
// Date Created: 01/27/2003
// Author:		 Jason K. Douglas
//
// MODIFICATION HISTORY:
//   DATE        SPR    INITIALS  DESCRIPTION
//   ----        ---    --------  --------------------------- 
//   01/27/03    000      jkd     First release
//
//=========================================================

using System;
using System.Net;
using PlayerNet.Messages;

namespace PlayerNet
{
	/// <summary>
	/// 
	/// </summary>
	public class GripperProxy : PlayerNet.ClientProxy
	{
		public static readonly byte GRIPopen = 1;
		public static readonly byte GRIPclose = 2;
		public static readonly byte GRIPstop = 3;
		public static readonly byte LIFTup = 4;
		public static readonly byte LIFTdown = 5;
		public static readonly byte LIFTstop = 6;
		public static readonly byte GRIPstore = 7;
		public static readonly byte GRIPdeploy = 8;
		public static readonly byte GRIPhalt = 15;
		public static readonly byte GRIPpress = 16;
		public static readonly byte LIFTcarry = 17;

		private bool myOpened = false;
		private bool myRaised = false;
		private bool myLiftMoving = false;
		private bool myPaddlesMoving = false;
		private bool myInnerBeamBroken = false;
		private bool myOuterBeamBroken = false;

		private object mySync = "GripperProxy sync";

		public bool Opened
		{
			get { lock (mySync) { return myOpened; } }
		}

		public bool Closed
		{
			get { lock (mySync) { return !Opened; } }
		}

		public bool Raised
		{
			get { lock (mySync) { return myRaised; } }
		}

		public bool Lowered
		{
			get { lock (mySync) { return !Raised; } }
		}

		public bool LiftMoving
		{
			get { lock (mySync) { return myLiftMoving; } }
		}

		public bool PaddlesMoving
		{
			get { lock (mySync) { return myPaddlesMoving; } }
		}

		public bool InnerBeamBroken
		{
			get { lock (mySync) { return myInnerBeamBroken; } }
		}

		public bool OuterBeamBroken
		{
			get { lock (mySync) { return myOuterBeamBroken; } }
		}

		public GripperProxy(PlayerClient pc) : this(pc, 0)
		{
		}

		public GripperProxy(PlayerClient pc, short index) : this(pc, index, 'a')
		{
		}

		public GripperProxy(PlayerClient pc, short index, char access) : base(pc, PlayerConnection.PLAYER_GRIPPER_CODE, index, access)
		{
		}

		public override void FillData(PlayerMsgHdr hdr, byte[] data)
		{
			unsafe
			{
				fixed (byte* pData = data)
				{
					PlayerGripperData* msg = (PlayerGripperData*)pData;

					byte state = msg->state;
					byte beams = msg->beams;
					lock (mySync)
					{
						myOuterBeamBroken = (beams & 0x04) != 0;
						myInnerBeamBroken = (beams & 0x08) != 0;

						myOpened = (state & 0x01) != 0;
						myRaised = (state & 0x10) != 0;

						myPaddlesMoving = (state & 0x04) != 0;
						myLiftMoving = (state & 0x40) != 0;
					}
				}
			}
		}

		public void Command(byte cmd, byte arg)
		{
			PlayerGripperCommand req;
			req.cmd = cmd;
			req.arg = arg;

			// Convert packet into a byte buffer
			byte[] data;
			unsafe
			{
				data = new byte[sizeof(PlayerGripperCommand)];
				byte* pReq = (byte*)&req;
				for (int i = 0; i < sizeof(PlayerGripperCommand); i++, pReq++)
					data[i] = *pReq;
			}

			Client.Write(Device, Index, data);
		}

		public void Command(byte cmd)
		{
			Command(cmd, 0);
		}
	}
}
