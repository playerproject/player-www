//=========================================================
// Filename: PtzProxy.cs
//
// Copyright (c) 2003 Applied Research Laboratory 
//                The Pennsylvania State University
//
// Purpose: Client proxy for commanding a pan/tilt/zoom device.
//
// Date Created: 01/27/2003
// Author:		 Jason K. Douglas
//
// MODIFICATION HISTORY:
//   DATE        SPR    INITIALS  DESCRIPTION
//   ----        ---    --------  --------------------------- 
//   01/27/03    000      jkd     First release
//
//=========================================================

using System;
using System.Net;
using PlayerNet.Messages;

namespace PlayerNet
{
	/// <summary>
	/// 
	/// </summary>
	public class PtzProxy : PlayerNet.ClientProxy
	{
		private short myPan = 0;
		private short myTilt = 0;
		private ushort myZoom = 0;

		private short myPanCommand = 0;
		private short myTiltCommand = 0;
		private ushort myZoomCommand = 1000;

		private object mySync = "PtzProxy sync";

		public short Pan
		{
			get { lock (mySync) { return myPan; } }
			set
			{
				lock (mySync)
				{
					myPanCommand = value;
					UpdatePtz();
				}
			}
		}

		public short Tilt
		{
			get { lock (mySync) { return myTilt; } }
			set
			{
				lock (mySync)
				{
					myTiltCommand = value;
					UpdatePtz();
				}
			}
		}

		public ushort Zoom
		{
			get { lock (mySync) { return myZoom; } }
			set
			{
				lock (mySync)
				{
					myZoomCommand = value;
					UpdatePtz();
				}
			}
		}

		public PtzProxy(PlayerClient pc) : this(pc, 0)
		{
		}

		public PtzProxy(PlayerClient pc, short index) : this(pc, index, 'a')
		{
		}

		public PtzProxy(PlayerClient pc, short index, char access) : base(pc, PlayerConnection.PLAYER_PTZ_CODE, index, access)
		{
		}

		public override void FillData(PlayerMsgHdr hdr, byte[] data)
		{
			unsafe
			{
				fixed (byte* pData = data)
				{
					// Parse the data buffer for PTZ fields
					PlayerPtzData* ptz = (PlayerPtzData*)pData;

					lock (mySync)
					{
						myPan = IPAddress.NetworkToHostOrder(ptz->pan);
						myTilt = IPAddress.NetworkToHostOrder(ptz->tilt);
						myZoom = (ushort)IPAddress.NetworkToHostOrder((short)ptz->zoom);
					}
				}
			}
		}

		private void UpdatePtz()
		{
			// Fill in the packet to update the PTZ
			PlayerPtzCommand cmd = new PlayerPtzCommand();
			cmd.pan = IPAddress.HostToNetworkOrder(myPanCommand);
			cmd.tilt = IPAddress.HostToNetworkOrder(myTiltCommand);
			cmd.zoom = (ushort)IPAddress.HostToNetworkOrder((short)myZoomCommand);

			// Convert the packet to a byte buffer
			byte[] data;
			unsafe
			{
				data = new byte[sizeof(PlayerPtzCommand)];
				byte* pCmd = (byte*)&cmd;
				for (int i = 0; i < data.Length; i++, pCmd++)
					data[i] = *pCmd;
			}

			// Write the packet to the robot
			Client.Write(Device, Index, data);
		}
	}
}
