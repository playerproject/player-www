//=========================================================
// Filename: PlayerClient.cs
//
// Copyright (c) 2003 Applied Research Laboratory 
//                The Pennsylvania State University
//
// Purpose: Provides the coommunications to the Player server
//			and maintains a list of available devices.
//
// Date Created: 01/27/2003
// Author:		 Jason K. Douglas
//
// MODIFICATION HISTORY:
//   DATE        SPR    INITIALS  DESCRIPTION
//   ----        ---    --------  --------------------------- 
//   01/27/03    000      jkd     First release
//	 02/28/03	 000	  jkd	  Fixed a bug with Connected property
//								  Added a destructor to disconnect
//								  Closes all proxies on disconnect
//
//=========================================================

using System;
using System.Collections;
using System.Diagnostics;
using System.Net;
using System.Threading;
using PlayerNet.Messages;

namespace PlayerNet
{
	public struct TimeStamp
	{
		public int Seconds;
		public int MicroSeconds;

		public static TimeStamp CurrentTime
		{
			get
			{
				// gettimeofday substitute
				TimeSpan dt = DateTime.Now - new DateTime(1970, 1, 1, 0, 0, 0, 0);
				TimeStamp ts = new TimeStamp();
				ts.Seconds = (int)(dt.Ticks / 10e6);
				ts.MicroSeconds = (int)(dt.Ticks - (int)(dt.Ticks / 10e6) * 10e6);
				return ts;
			}
		}

		/// <summary>
		/// Produces a unique hash code, used for indexing in lists.
		/// </summary>
		/// <returns>Hash value</returns>
		public override int GetHashCode()
		{
			return Seconds + MicroSeconds;
		}

		/// <summary>
		/// Method for determining if two objects are equivalent.
		/// </summary>
		/// <param name="o">Object to compare against</param>
		/// <returns>True, if the objects are equal. False, otherwise.</returns>
		public override bool Equals(object o)
		{
			if (o == null)
				return false;

			if (o.GetType() != GetType())
				return false;

			TimeStamp rhs = (TimeStamp)o;

			if (rhs.Seconds == Seconds && rhs.MicroSeconds == MicroSeconds)
				return true;

			return false;
		}

		/// <summary>
		/// Equivalence operator for comparing two objects.
		/// </summary>
		/// <param name="lhs">This object</param>
		/// <param name="rhs">The object to compare against</param>
		/// <returns>True, if the objects are equal. False, otherwise.</returns>
		public static bool operator ==(TimeStamp lhs, TimeStamp rhs)
		{
			if ((object)lhs == null)
			{
				if ((object)rhs != null)
					return false;
				else
					return true;
			}

			return lhs.Equals(rhs);
		}

		/// <summary>
		/// Non-equivalence operator for comparing two objects.
		/// </summary>
		/// <param name="lhs">This object</param>
		/// <param name="rhs">The object to compare against</param>
		/// <returns>True, if the objects are not equal. False, otherwise.</returns>
		public static bool operator !=(TimeStamp lhs, TimeStamp rhs)
		{
			// Re-use the functionality of the equivalence operator
			return !(lhs == rhs);
		}

		/// <summary>
		/// Less-than operator for comparing two timestamps.
		/// </summary>
		/// <param name="lhs">This timestamp object</param>
		/// <param name="rhs">The timestamp object to compare against</param>
		/// <returns>
		/// True, if this timestamp is less than the timestamp being compared against.
		/// False, otherwise.
		/// </returns>
		public static bool operator <(TimeStamp lhs, TimeStamp rhs)
		{
			if (lhs.Seconds < rhs.Seconds)
				return true;

			if (lhs.Seconds == rhs.Seconds && lhs.MicroSeconds < rhs.MicroSeconds)
				return true;

			return false;
		}

		/// <summary>
		/// Greater-than operator for comparing two timestamps.
		/// </summary>
		/// <param name="lhs">This timestamp object</param>
		/// <param name="rhs">The timestamp object to compare against</param>
		/// <returns>
		/// True, if this timestamp is greater than the timestamp being compared against.
		/// False, otherwise.
		/// </returns>
		public static bool operator >(TimeStamp lhs, TimeStamp rhs)
		{
			// Check for equality first
			if (lhs == rhs)
				return false;

			// Utilize the overloaded '<' operator functionality
			return !(lhs < rhs);
		}
	}

	/// <summary>
	/// 
	/// </summary>
	public class PlayerClient
	{
		public static readonly byte PLAYER_DATA_MODE_PUSH_ALL = 0;
		public static readonly byte PLAYER_DATA_MODE_PULL_ALL = 1;
		public static readonly byte PLAYER_DATA_MODE_PUSH_NEW = 2;
		public static readonly byte PLAYER_DATA_MODE_PULL_NEW = 3;

		private PlayerConnection myConnection = new PlayerConnection();
		private byte myDataMode = PLAYER_DATA_MODE_PUSH_ALL;
		private short myFrequency = 10;
		private ArrayList myProxies = new ArrayList();
		private Thread myReadThread = null;

		public bool Connected
		{
			get { return myConnection != null && myConnection.Connected; }
		}

		public string Banner
		{
			get
			{
				if (myConnection == null)
					return "";

				return myConnection.Banner;
			}
		}

		public byte DataMode
		{
			set
			{
				myDataMode = value;

				// Setup a packet to request a data mode change
				PlayerDeviceDataModeReq req;
				req.subtype = IPAddress.HostToNetworkOrder(PlayerConnection.PLAYER_PLAYER_DATAMODE_REQ);
				req.mode = myDataMode;

				// Convert packet to a byte buffer
				byte[] data;
				unsafe
				{
					data = new byte[sizeof(PlayerDeviceDataModeReq)];
					byte* pReq = (byte*)&req;
					for (int i = 0; i < sizeof(PlayerDeviceDataModeReq); i++, pReq++)
						data[i] = *pReq;
				}

				// Send request for the data mode change, but do not read a reply
				Request(PlayerConnection.PLAYER_PLAYER_CODE, 0, data);
			}
			get { return myDataMode; }
		}

		public short Frequency
		{
			set
			{
				myFrequency = value;

				// Setup a packet to request the frequency change
				PlayerDeviceDataFreqReq req;
				req.subtype = IPAddress.HostToNetworkOrder(PlayerConnection.PLAYER_PLAYER_DATAFREQ_REQ);
				req.frequency = IPAddress.HostToNetworkOrder(myFrequency);

				// Convert packet to a byte buffer
				byte[] data;
				unsafe
				{
					data = new byte[sizeof(PlayerDeviceDataFreqReq)];
					byte* pReq = (byte*)&req;
					for (int i = 0; i < sizeof(PlayerDeviceDataFreqReq); i++, pReq++)
						data[i] = *pReq;
				}

				// Send request for the frequency change, but do not read a reply
				Request(PlayerConnection.PLAYER_PLAYER_CODE, 0, data);
			}
			get { return myFrequency; }
		}

		private int ReadProxyCount
		{
			get
			{
				int count = 0;
				foreach (ClientProxy p in myProxies)
				{
					if (p.Access == 'a' || p.Access == 'r')
						count++;
				}
				return count;
			}
		}

		public PlayerClient()
		{
			Connect();
		}

		public PlayerClient(string hostname)
		{
			Connect(hostname);
		}

		public PlayerClient(string hostname, int port)
		{
			Connect(hostname, port);
		}

		~PlayerClient()
		{
			Disconnect();
		}

		public void Connect()
		{
			if (myConnection == null)
				myConnection = new PlayerConnection();

			myConnection.Connect();
		}

		public void Connect(string hostname)
		{
			if (myConnection == null)
				myConnection = new PlayerConnection();

			myConnection.Connect(hostname);
		}

		public void Connect(string hostname, int port)
		{
			if (myConnection == null)
				myConnection = new PlayerConnection();

			myConnection.Connect(hostname, port);
		}

		public void Disconnect()
		{
			//Trace.WriteLine("Disconnecting PlayerClient");

			ClientProxy[] cps = new ClientProxy[myProxies.Count];
			for (int i = 0; i < myProxies.Count; i++)
				cps[i] = (ClientProxy)myProxies[i];

			for (int i = 0; i < cps.Length; i++)
				RemoveProxy(cps[i]);

			myConnection = null;
		}

		internal void AddProxy(ClientProxy proxy)
		{
			if (proxy != null)
				myProxies.Add(proxy);
			else
				throw new ArgumentNullException("proxy");
		}

		internal void RemoveProxy(ClientProxy proxy)
		{
			if (proxy != null)
			{
				proxy.Close();
				myProxies.Remove(proxy);
			}
			else
				throw new ArgumentNullException("proxy");
		}

		private ClientProxy GetProxy(short device, short index)
		{
			foreach (ClientProxy p in myProxies)
			{
				if (p.Device == device && p.Index == index)
					return p;
			}

			return null;
		}

		internal void Request(short device, short index, byte[] data)
		{
			// Can't make requests if you're not connected
			if (!Connected)
				return;

			myConnection.Request(device, index, data);
		}

		internal void Request(short device, short index, byte[] data, ref PlayerMsgHdr replyHdr, ref byte[] replyData)
		{
			// Can't make requests if you're not connected
			if (!Connected)
				return;

			myConnection.Request(device, index, data, ref replyHdr, ref replyData);
		}

		private void RequestData()
		{
			// Can't make requests if you're not connected
			if (!Connected)
				return;

			// Setup an packet to request the data
			PlayerDeviceDataReq req;
			req.subtype = IPAddress.HostToNetworkOrder(PlayerConnection.PLAYER_PLAYER_DATA_REQ);

			// Convert packet to a byte buffer
			byte[] data;
			unsafe
			{
				data = new byte[sizeof(PlayerDeviceDataReq)];
				byte* pReq = (byte*)&req;
				for (int i = 0; i < sizeof(PlayerDeviceDataReq); i++, pReq++)
					data[i] = *pReq;
			}

			// Send request for the data, but do not read a reply
			Request(PlayerConnection.PLAYER_PLAYER_CODE, 0, data);
		}

		internal char RequestDeviceAccess(short device, short index,char requestedAccess)
		{
			// Can't make requests if you're not connected
			if (!Connected)
				return 'e';

			return myConnection.RequestDeviceAccess(device, index, requestedAccess);
		}

		internal void Write(short device, short index, byte[] data)
		{
			// Can't write if you're not connected
			if (!Connected)
				return;

			myConnection.Write(device, index, data);
		}

		public void Read()
		{
			// Can't read if you're not connected
			if (!Connected)
				return;

			// If we are pulling the data in request/reply mode, request a packet before reading
			if (DataMode == PLAYER_DATA_MODE_PULL_ALL || DataMode == PLAYER_DATA_MODE_PULL_NEW)
				RequestData();

			// Read packets for each proxy connected
			for (int nReads = ReadProxyCount; nReads > 0; nReads--)
			{
				try
				{
					PlayerMsgHdr hdr = new PlayerMsgHdr();
					byte[] data = null;
					myConnection.Read(ref hdr, ref data);

					ClientProxy proxy = GetProxy(hdr.device, hdr.device_index);
					if (proxy == null)
						continue;

					// Put the data in the object
					if (hdr.size > 0)
						proxy.FillData(hdr, data);

					// Fill in the timestamps
					TimeStamp curr = TimeStamp.CurrentTime;
					proxy.SetDataTime(hdr.timestamp_sec, hdr.timestamp_usec);
					proxy.SetSentTime(hdr.time_sec, hdr.time_usec);
					proxy.SetReceivedTime(curr.Seconds, curr.MicroSeconds);
				}
				catch (Exception)
				{
				}
			}
		}

		private void ReadThread()
		{
			while (true)
			{
				try
				{
					Read();
				}
				catch (Exception)
				{
				}
			}
		}

		public void StartReads()
		{
			StopReads();

			myReadThread = new Thread(new ThreadStart(ReadThread));
			myReadThread.Name = "PlayerClient connected to " + myConnection.Hostname + ":" + myConnection.Port;
			myReadThread.Start();
		}

		public void StopReads()
		{
			if (myReadThread != null)
				myReadThread.Abort();
		}
	}
}
