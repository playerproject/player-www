//=========================================================
// Filename: BlobFinderProxy.cs
//
// Copyright (c) 2003 Applied Research Laboratory 
//                The Pennsylvania State University
//
// Purpose: Client proxy for detecting color blobs on a camera.
//
// Date Created: 01/27/2003
// Author:		 Jason K. Douglas
//
// MODIFICATION HISTORY:
//   DATE        SPR    INITIALS  DESCRIPTION
//   ----        ---    --------  --------------------------- 
//   01/27/03    000      jkd     First release
//
//=========================================================

using System;
using System.Net;
using PlayerNet.Messages;

namespace PlayerNet
{
	public class Blob
	{
		public uint Area = 0;
		public ushort X = 0;
		public ushort Y = 0;
		public ushort Left = 0;
		public ushort Right = 0;
		public ushort Top = 0;
		public ushort Bottom = 0;
	};

	/// <summary>
	/// Summary description for BlobFinderProxy.
	/// </summary>
	public class BlobFinderProxy : PlayerNet.ClientProxy
	{
		public static readonly int MAX_CHANNELS = 32;

		private Blob[][] myBlobs = new Blob[MAX_CHANNELS][];
		private ushort myHeight = 0;
		private ushort myWidth = 0;
		private object mySync = "BlobFinderProxy sync";

		public Blob[] this[int channel]
		{
			get { lock (mySync) { return myBlobs[channel]; } }
		}

		public ushort Height
		{
			get { lock (mySync) { return myHeight; } }
		}

		public ushort Width
		{
			get { lock (mySync) { return myWidth; } }
		}

		// CLS-compliant method
		public Blob[] GetBlobs(int channel)
		{
			lock (mySync) { return myBlobs[channel]; }
		}

		public BlobFinderProxy(PlayerClient pc) : this(pc, 0)
		{
		}

		public BlobFinderProxy(PlayerClient pc, short index) : this(pc, index, 'r')
		{
		}

		public BlobFinderProxy(PlayerClient pc, short index, char access) : base(pc, PlayerConnection.PLAYER_VISION_CODE, index, access)
		{
		}

		public override void FillData(PlayerMsgHdr hdr, byte[] data)
		{
			unsafe
			{
				lock (mySync)
				{
					fixed (byte* pData = data)
					{
						PlayerBlobFinderData* msg = (PlayerBlobFinderData*)pData;
						myHeight = (ushort)IPAddress.NetworkToHostOrder((short)msg->height);
						myWidth = (ushort)IPAddress.NetworkToHostOrder((short)msg->width);

						ushort[] index = new ushort[MAX_CHANNELS];
						for (int i = 0; i < MAX_CHANNELS; i++)
						{
							PlayerBlobFinderHeader* header = (PlayerBlobFinderHeader*)(pData + sizeof(PlayerBlobFinderData) + i * sizeof(PlayerBlobFinderHeader));
							index[i] = (ushort)IPAddress.NetworkToHostOrder((short)header->index);
							ushort blobs = (ushort)IPAddress.NetworkToHostOrder((short)header->num);

							myBlobs[i] = new Blob[blobs];
						}

						// Monitor all vision channels
						for (int i = 0; i < MAX_CHANNELS; i++)
						{
							// Decode data for each blob on this channel
							for (int j = 0; j < myBlobs[i].Length; j++)
							{
								myBlobs[i][j] = new Blob();
								try
								{
									PlayerBlobData* blob = (PlayerBlobData*)(pData + index[i] * sizeof(PlayerBlobData)
										+ sizeof(PlayerBlobFinderData) + MAX_CHANNELS * sizeof(PlayerBlobFinderHeader));
									myBlobs[i][j].Area = (uint)IPAddress.NetworkToHostOrder((int)blob->area);
									myBlobs[i][j].X = (ushort)IPAddress.NetworkToHostOrder((short)blob->x);
									myBlobs[i][j].Y = (ushort)IPAddress.NetworkToHostOrder((short)blob->y);
									myBlobs[i][j].Top = (ushort)IPAddress.NetworkToHostOrder((short)blob->top);
									myBlobs[i][j].Bottom = (ushort)IPAddress.NetworkToHostOrder((short)blob->bottom);
									myBlobs[i][j].Right = (ushort)IPAddress.NetworkToHostOrder((short)blob->right);
									myBlobs[i][j].Left = (ushort)IPAddress.NetworkToHostOrder((short)blob->left);
								}
								catch (NullReferenceException)
								{
								}
							}
						}
					}
				}
			}
		}
	}
}
