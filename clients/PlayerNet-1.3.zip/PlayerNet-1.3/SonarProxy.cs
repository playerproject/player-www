//=========================================================
// Filename: SonarProxy.cs
//
// Copyright (c) 2003 Applied Research Laboratory 
//                The Pennsylvania State University
//
// Purpose: Client proxy for reading sonar distance values.
//
// Date Created: 01/27/2003
// Author:		 Jason K. Douglas
//
// MODIFICATION HISTORY:
//   DATE        SPR    INITIALS  DESCRIPTION
//   ----        ---    --------  --------------------------- 
//   01/27/03    000      jkd     First release
//
//=========================================================

using System;
using System.Net;
using PlayerNet.Messages;

namespace PlayerNet
{
	/*
	public class SonarPose
	{
		// The number of valid poses.
		private ushort myPoseCount = SonarProxy.PLAYER_NUM_SONAR_SAMPLES;

		// Pose of each sonar, in robot cs (mm, mm, degrees).
		private short[,] myPoses = new short[SonarProxy.PLAYER_NUM_SONAR_SAMPLES, 3];

		public ushort Count
		{
			set { myPoseCount = value; }
			get { return myPoseCount; }
		}

		public short this[int sample, int pose]
		{
			set { myPoses[sample, pose] = value; }
			get { return myPoses[sample, pose]; }
		}
	}
	*/

	/// <summary>
	/// 
	/// </summary>
	public class SonarProxy : PlayerNet.ClientProxy
	{
		public static readonly ushort PLAYER_SONAR_POWER_REQ = 11;
		public static readonly ushort PLAYER_SONAR_GET_GEOM_REQ = 12;
		public static readonly ushort PLAYER_NUM_SONAR_SAMPLES = 16;

		private ushort[] myRanges = new ushort[PLAYER_NUM_SONAR_SAMPLES];
		private ushort myCount = PLAYER_NUM_SONAR_SAMPLES;

		private object mySync = "SonarProxy sync";

		public ushort this[int index]
		{
			get { lock (mySync) { return myRanges[index]; } }
		}

		public ushort Count
		{
			get { lock (mySync) { return myCount; } }
		}

		// CLS-compliant method
		public ushort GetRange(int index)
		{
			lock (mySync) { return myRanges[index]; }
		}

		public SonarProxy(PlayerClient pc) : this(pc, 0)
		{
		}

		public SonarProxy(PlayerClient pc, short index) : this(pc, index, 'r')
		{
		}

		public SonarProxy(PlayerClient pc, short index, char access) : base(pc, PlayerConnection.PLAYER_SONAR_CODE, index, access)
		{
		}

		public override void FillData(PlayerMsgHdr hdr, byte[] data)
		{
			lock (mySync)
			{
				// Read the number of sonar readings first
				myCount = (ushort)IPAddress.NetworkToHostOrder(BitConverter.ToInt16(data, 0));

				// Resize the range reading array, if the size doesn't agree
				if (myCount != myRanges.Length)
					myRanges = new ushort[myCount];

				unsafe
				{
					// Read the ranges
					for (int n = 0; n < myCount; n++)
						myRanges[n] = (ushort)IPAddress.NetworkToHostOrder(BitConverter.ToInt16(data, sizeof(ushort) + (n * sizeof(ushort))));
				}
			}
		}
	}
}
