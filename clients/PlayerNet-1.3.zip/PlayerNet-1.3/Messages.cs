//=========================================================
// Filename: Messages.cs
//
// Copyright (c) 2003 Applied Research Laboratory 
//                The Pennsylvania State University
//
// Purpose: Network messages being tramsitted to and from
//			the Player server.
//
// Date Created: 01/27/2003
// Author:		 Jason K. Douglas
//
// MODIFICATION HISTORY:
//   DATE        SPR    INITIALS  DESCRIPTION
//   ----        ---    --------  --------------------------- 
//   01/27/03    000      jkd     First release
//
//=========================================================

using System;
using System.Runtime.InteropServices;

namespace PlayerNet
{
	namespace Messages
	{
		[StructLayout(LayoutKind.Sequential, Pack=1, CharSet=CharSet.Ansi)]
		public struct PlayerMsgHdr
		{
			public short stx;
			public short type;
			public short device;
			public short device_index;
			public int time_sec;
			public int time_usec;
			public int timestamp_sec;
			public int timestamp_usec;
			public int reserved;
			public int size;
		};

		[StructLayout(LayoutKind.Sequential, Pack=1, CharSet=CharSet.Ansi)]
		public struct PlayerDeviceReq
		{
			public ushort subtype;
			public ushort code;
			public ushort index;
			public byte access;		// char data type is two bytes in Unicode
		};

		[StructLayout(LayoutKind.Sequential, Pack=1, Size=7 + PlayerConnection.PLAYER_MAX_DEVICE_STRING_LEN, CharSet=CharSet.Ansi)]
		public struct PlayerDeviceResp
		{
			public ushort subtype;
			public ushort code;
			public ushort index;
			public byte access;		// char data type is two bytes in Unicode
		};

		[StructLayout(LayoutKind.Sequential, Pack=1, CharSet=CharSet.Ansi)]
		public struct PlayerDeviceDataModeReq
		{
			public short subtype;
			// 0 = continuous (default)
			// 1 = request/reply
			public byte mode;
		};

		[StructLayout(LayoutKind.Sequential, Pack=1, CharSet=CharSet.Ansi)]
		public struct PlayerDeviceDataFreqReq
		{
			public short subtype;
			// frequency in Hz
			public short frequency;
		};

		[StructLayout(LayoutKind.Sequential, Pack=1, CharSet=CharSet.Ansi)]
		public struct PlayerDeviceDataReq
		{
			public short subtype;
		};

		[StructLayout(LayoutKind.Sequential, Pack=1, CharSet=CharSet.Ansi)]
		public struct PlayerPositionData
		{
			public int xpos;
			public int ypos;
			public int yaw; 
			public int xspeed;
			public int yspeed; 
			public int yawspeed;
			public byte stall;
		};

		[StructLayout(LayoutKind.Sequential, Pack=1, CharSet=CharSet.Ansi)]
		public struct PlayerPositionCommand
		{
			public int xpos;
			public int ypos;
			public int yaw;
			public int xspeed;
			public int yspeed;
			public int yawspeed;
		};

		[StructLayout(LayoutKind.Sequential, Pack=1, CharSet=CharSet.Ansi)]
		public struct PlayerPtzCommand
		{
			public short pan;	// -100 to 100 degrees, increases counter-clockwise
			public short tilt;	// -25 to 25 degrees, increases up
			public ushort zoom;	// 0 to 1023, 0 is wide and 1023 is telefoto
		};

		[StructLayout(LayoutKind.Sequential, Pack=1, CharSet=CharSet.Ansi)]
		public struct PlayerPtzData
		{
			public short pan;
			public short tilt;
			public ushort zoom;
		};

		[StructLayout(LayoutKind.Sequential, Pack=1, CharSet=CharSet.Ansi)]
		public struct PlayerMiscData
		{
			public byte frontbumpers;
			public byte rearbumpers;
			public byte voltage;
			public byte analog;
			public byte digin;
		};

		[StructLayout(LayoutKind.Sequential, Pack=1, CharSet=CharSet.Ansi)]
		public struct PlayerGripperCommand
		{
			public byte cmd;
			public byte arg;
		};

		[StructLayout(LayoutKind.Sequential, Pack=1, CharSet=CharSet.Ansi)]
		public struct PlayerGripperData
		{
			public byte state;
			public byte beams;
		};

		[StructLayout(LayoutKind.Sequential, Pack=1, CharSet=CharSet.Ansi)]
		public struct PlayerSonarConfig
		{
			/* Packet subtype.  Must be PLAYER_SONAR_POWER_REQ. */
			public byte subtype;

			/* Turn sonars on or off. */
			public byte arg;
		};

		[StructLayout(LayoutKind.Sequential, Pack=1, CharSet=CharSet.Ansi)]
		public struct PlayerBlobELT
		{
			public ushort index, num;
		};

		[StructLayout(LayoutKind.Sequential, Pack=1, CharSet=CharSet.Ansi)]
		public struct PlayerBlobData
		{
			/* A descriptive color for the blob (useful for gui's).
			 * The color is stored as packed 32-bit RGB, i.e., 0x00RRGGBB. */
			public uint color;

			/* The blob area (pixels). */
			public uint area;

			/* The blob centroid (image coords). */
			public ushort x, y;

			/* Bounding box for the blob (image coords). */
			public ushort left, right, top, bottom;

			/* Range (mm) to the blob center */
			public ushort range;
		};

		[StructLayout(LayoutKind.Sequential, Pack=1, CharSet=CharSet.Ansi)]
		public struct PlayerBlobFinderData
		{
			public ushort width, height;
		};

		[StructLayout(LayoutKind.Sequential, Pack=1, CharSet=CharSet.Ansi)]
		public struct PlayerBlobFinderHeader
		{
			public ushort index, num;
		};

		[StructLayout(LayoutKind.Sequential, Pack=1, CharSet=CharSet.Ansi)]
		public struct PlayerLaserConfig
		{
			/* The packet subtype.  Set this to PLAYER_LASER_SET_CONFIG to set
			 * the laser configuration; or set to PLAYER_LASER_GET_CONFIG to get
			 * the laser configuration.  */
			public byte subtype;

			/* Start and end angles for the laser scan (in units of 0.01
			 * degrees).  Valid range is -9000 to +9000.  */
			public short min_angle;
			public short max_angle;

			/* Scan resolution (in units of 0.01 degrees).  Valid resolutions
			 * are 25, 50, 100.  */
			public ushort resolution;

			/* Enable reflection intensity data. */
			public byte intensity;
		};

		[StructLayout(LayoutKind.Sequential, Pack=1, CharSet=CharSet.Ansi)]
		public struct PlayerLaserGeometry
		{
			/* The packet subtype.  Must be PLAYER_LASER_GET_GEOM. */
			public byte subtype;

			/* Laser pose, in robot cs (mm, mm, radians). */
			public short pose1;
			public short pose2;
			public short pose3;

			/* Laser dimensions (mm, mm). */
			public short size1;
			public short size2;
		};
	}
}