//=========================================================
// Filename: ClientProxy.cs
//
// Copyright (c) 2003 Applied Research Laboratory 
//                The Pennsylvania State University
//
// Purpose: Base functionality for all client device proxies.
//
// Date Created: 01/27/2003
// Author:		 Jason K. Douglas
//
// MODIFICATION HISTORY:
//   DATE        SPR    INITIALS  DESCRIPTION
//   ----        ---    --------  --------------------------- 
//   01/27/03    000      jkd     First release
//	 02/28/03	 000	  jkd	  Added a destructor to close the proxy
//
//=========================================================

using System;
using System.Diagnostics;
using PlayerNet.Messages;

namespace PlayerNet
{
	/// <summary>
	/// 
	/// </summary>
	public abstract class ClientProxy
	{
		private PlayerClient myClient = null;
		private char myAccess = 'e';
		private short myDevice = 0;
		private short myIndex = 0;
		private TimeStamp myDataTime;
		private TimeStamp myReceivedTime;
		private TimeStamp mySentTime;

		public PlayerClient Client
		{
			get { return myClient; }
			set { myClient = value; }
		}

		public char Access
		{
			get { return myAccess; }
			set { myAccess = value; }
		}

		public short Device
		{
			get { return myDevice; }
			set { myDevice = value; }
		}

		public short Index
		{
			get { return myIndex; }
			set { myIndex = value; }
		}

		public TimeStamp DataTime
		{
			get { return myDataTime; }
		}

		public TimeStamp SentTime
		{
			get { return mySentTime; }
		}

		public TimeStamp ReceivedTime
		{
			get { return myReceivedTime; }
		}

		public ClientProxy(PlayerClient pc, short device) : this(pc, device, 0)
		{
		}

		public ClientProxy(PlayerClient pc, short device, short index) : this(pc, device, index, 'a')
		{
		}

		public ClientProxy(PlayerClient pc, short device, short index, char access)
		{
			Client = pc;
			Device = device;
			Index = index;
			Access = access;

			Client.AddProxy(this);

			char grantedAccess = ChangeAccess(access);
			if (grantedAccess != access)
				throw new Exception("Requested '" + access + "' access, but got '" + grantedAccess +
									"' instead (Device " + device + ":" + index + ")");
		}

		~ClientProxy()
		{
			Close();
		}

		// Returns the granted access
		public char ChangeAccess(char access)
		{
			return Client.RequestDeviceAccess(Device, Index, access);
		}

		// Closes access to the device
		public bool Close()
		{
			//Trace.WriteLine("Closing proxy (" + Device + ":" + Index + ")");
			if (ChangeAccess('c') == 'c')
				return true;

			return false;
		}

		public void SetDataTime(int sec, int usec)
		{
			myDataTime.Seconds = sec;
			myDataTime.MicroSeconds = usec;
		}

		public void SetSentTime(int sec, int usec)
		{
			mySentTime.Seconds = sec;
			mySentTime.MicroSeconds = usec;
		}

		public void SetReceivedTime(int sec, int usec)
		{
			myReceivedTime.Seconds = sec;
			myReceivedTime.MicroSeconds = usec;
		}

		public abstract void FillData(PlayerMsgHdr hdr, byte[] data);
	}
}
