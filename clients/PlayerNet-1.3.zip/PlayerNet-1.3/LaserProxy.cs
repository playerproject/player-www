//=========================================================
// Filename: LaserProxy.cs
//
// Copyright (c) 2003 Applied Research Laboratory 
//                The Pennsylvania State University
//
// Purpose: Client proxy for reading laser rangefinder distances.
//
// Date Created: 01/27/2003
// Author:		 Jason K. Douglas
//
// MODIFICATION HISTORY:
//   DATE        SPR    INITIALS  DESCRIPTION
//   ----        ---    --------  --------------------------- 
//   01/27/03    000      jkd     First release
//
//=========================================================

using System;
using System.Net;
using PlayerNet.Messages;

namespace PlayerNet
{
	/// <summary>
	/// 
	/// </summary>
	public class LaserProxy : PlayerNet.ClientProxy
	{
		public static readonly byte PLAYER_LASER_SET_CONFIG = 0x01;
		public static readonly byte PLAYER_LASER_GET_CONFIG = 0x02;
		public static readonly byte PLAYER_LASER_GET_GEOM = 0x03;

		public static readonly int PLAYER_NUM_LASER_SAMPLES = 401;


		/** Scan range for the latest set of data.
			Angles are measured in units of $0.01^{\circ}$,
			in the range -9000 ($-90^{\circ}$) to
			+9000 ($+90^{\circ}$).
		*/
		private short myMaxAngle = 0;
		private short myMinAngle = 0;

		/** Scan resolution for the latest set of data.
			Resolution is measured in units of $0.01^{\circ}$.
			Valid choices are: 25, 50, and 100.
		*/
		private ushort myResolution;

		/** Whether or not reflectance values are returned.
		  */
		private bool myIntensity;

		// The number of range measurements in the latest set of data.
		private ushort myCount;

		/// The range values (in mm).
		private ushort[] myRanges = new ushort[PLAYER_NUM_LASER_SAMPLES];

		// TODO: haven't verified that intensities work yet:
		/// The reflected intensity values (arbitrary units in range 0-7).
		private byte[] myIntensities = new byte[PLAYER_NUM_LASER_SAMPLES];

		// Minimum left and right range readings
		private ushort myMinRight = 10000;
		private ushort myMinLeft = 10000;

		private object mySync = "LaserProxy sync";

		public ushort Count
		{
			get { lock (mySync) { return myCount; } }
		}

		public ushort this[int index]
		{
			get { lock (mySync) { return Ranges[index]; } }
		}

		public ushort[] Ranges
		{
			get { lock (mySync) { return myRanges; } }
		}

		public byte[] Intensities
		{
			get { lock (mySync) { return myIntensities; } }
		}

		public ushort MinRight
		{
			get { lock (mySync) { return myMinRight; } }
		}

		public ushort MinLeft
		{
			get { lock (mySync) { return myMinLeft; } }
		}

		public short MaxAngle
		{
			get { lock (mySync) { return myMaxAngle; } }
		}

		public short MinAngle
		{
			get { lock (mySync) { return myMinAngle; } }
		}

		public ushort Resolution
		{
			get { lock (mySync) { return myResolution; } }
		}

		public bool Intensity
		{
			get { lock (mySync) { return myIntensity; } }
		}

		// CLS-compliant method
		public ushort GetRange(int index)
		{
			lock (mySync) { return Ranges[index]; }
		}

		public LaserProxy(PlayerClient pc) : this(pc, 0)
		{
		}

		public LaserProxy(PlayerClient pc, short index) : this(pc, index, 'r')
		{
		}

		public LaserProxy(PlayerClient pc, short index, char access) : base(pc, PlayerConnection.PLAYER_LASER_CODE, index, access)
		{
		}

		public void Configure(short minAngle, short maxAngle, ushort resolution, bool intensity)
		{
			if (Client == null)
				return;

			PlayerLaserConfig req;

			req.subtype = PLAYER_LASER_SET_CONFIG;
			req.min_angle = IPAddress.HostToNetworkOrder(minAngle);
			req.max_angle = IPAddress.HostToNetworkOrder(maxAngle);
			req.resolution = (ushort)IPAddress.HostToNetworkOrder((short)resolution);
			req.intensity = (byte)(intensity ? 1 : 0);

			// Copy them locally
			lock (mySync)
			{ 
				myMinAngle = minAngle;
				myMaxAngle = maxAngle;
				myResolution = resolution;
				myIntensity = intensity;
			}

			// Convert packet into a byte buffer
			byte[] data;
			unsafe
			{
				data = new byte[sizeof(PlayerLaserConfig)];
				byte* pReq = (byte*)&req;
				for (int i = 0; i < sizeof(PlayerLaserConfig); i++, pReq++)
					data[i] = *pReq;
			}

			Client.Request(Device, Index, data);
		}

		// FIXME: seems to hang on reading the reply
		public void GetConfigure()
		{
			if (Client == null)
				return;

			// Single byte required to request the laser configuration
			byte[] data = new byte[]{PLAYER_LASER_GET_CONFIG};

			// Send the request for laser configuration and read the reply
			PlayerMsgHdr replyHeader = new PlayerMsgHdr();
			byte[] replyData = null;
			Client.Request(Device, Index, data,	ref replyHeader, ref replyData);

			unsafe
			{
				fixed (byte* pData = replyData)
				{
					// Pull configuration fields out of the reply buffer
					PlayerLaserConfig* config = (PlayerLaserConfig*)pData;

					lock (mySync)
					{
						myMinAngle = IPAddress.NetworkToHostOrder(config->min_angle);
						myMaxAngle = IPAddress.NetworkToHostOrder(config->max_angle);
						myResolution = (ushort)IPAddress.NetworkToHostOrder((short)config->resolution);
						myIntensity = config->intensity == 1;
					}
				}
			}
		}

		public override void FillData(PlayerMsgHdr hdr, byte[] data)
		{
			lock (mySync)
			{
				myMinAngle = IPAddress.NetworkToHostOrder(BitConverter.ToInt16(data, 0));
				myMaxAngle = IPAddress.NetworkToHostOrder(BitConverter.ToInt16(data, 2));
				myResolution = (ushort)IPAddress.NetworkToHostOrder(BitConverter.ToInt16(data, 4));
				myCount = (ushort)IPAddress.NetworkToHostOrder(BitConverter.ToInt16(data, 6));

				myMinLeft = 10000;
				myMinRight = 10000;

				for (int i = 0; i < myCount && i < PLAYER_NUM_LASER_SAMPLES; i++)
				{
					short n = 0;
					unsafe
					{
						n = BitConverter.ToInt16(data, 8 + sizeof(ushort) * i);
						n = (short)IPAddress.NetworkToHostOrder(n);
					}

					myRanges[i] = (ushort)(n & 0x1FFF);	// Lower 13 bits for range info
					myIntensities[i] = (byte)(n >> 13);	// Upper 3 bits for intensity info

					// Check for the minimum right and left values
					if (i > myCount / 2 && myRanges[i] < myMinLeft)
						myMinLeft = myRanges[i];
					else if (i < myCount / 2 && myRanges[i] < myMinRight)
						myMinRight = myRanges[i];
				}
			}
		}
	}
}
