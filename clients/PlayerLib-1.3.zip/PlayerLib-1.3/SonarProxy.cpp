// PlayerLib - A Win32 client library for Player
// Copyright (C) 2001,2002
//    Jason K. Douglas, Applied Research Labs, Penn State University
//
//
// Based entirely on:
//   Player - One Hell of a Robot Server
//   Copyright (C) 2000  
//      Brian Gerkey, Kasper Stoy, Richard Vaughan, & Andrew Howard
//                     
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
///////////////////////////////////////


#include <math.h>

#include "SonarProxy.h"
#include "PlayerClient.h"

SonarProxy::SonarProxy(PlayerClient* p_pClient, unsigned short p_nIndex,
					   unsigned char p_chReqAccess)
					   : ClientProxy(p_pClient, PLAYER_SONAR_CODE, p_nIndex, p_chReqAccess)
{
	memset(&m_SonarPose, 0, sizeof(m_SonarPose));
}

SonarProxy::~SonarProxy()
{

}

int SonarProxy::SetSonarState(bool p_bOn)
{
	if (!m_pClient)
		return -1;

	player_sonar_power_config_t config;
	config.subtype = PLAYER_SONAR_POWER_REQ;
	config.value = p_bOn?1:0;

	return m_pClient->Request(PLAYER_SONAR_CODE, GetIndex(), (LPCSTR)&config, sizeof(config));
}

unsigned short SonarProxy::operator [](unsigned int p_nIndex)
{
	if (p_nIndex < sizeof(m_arrRanges))
		return m_arrRanges[p_nIndex];

	return 0;
}

int SonarProxy::GetSonarPose()
{
	if (!m_pClient)
		return -1;

	player_msghdr_t hdr;
	player_sonar_geom_t req;
	req.subtype = PLAYER_SONAR_GET_GEOM_REQ;

	if (m_pClient->Request(PLAYER_SONAR_CODE, GetIndex(), (LPCSTR)&req,
		sizeof(req.subtype), &hdr, (LPSTR)&m_SonarPose, sizeof(m_SonarPose)) < 0 ||
		hdr.type != PLAYER_MSGTYPE_RESP_ACK)
		return -1;

	m_SonarPose.pose_count = ntohs(m_SonarPose.pose_count);
	for (int i = 0; i < m_SonarPose.pose_count; i++)
	{
		m_SonarPose.poses[i][0] = ntohs(m_SonarPose.poses[i][0]);
		m_SonarPose.poses[i][1] = ntohs(m_SonarPose.poses[i][1]);
		m_SonarPose.poses[i][2] = ntohs(m_SonarPose.poses[i][2]);
	}

	return 0;
}

unsigned short SonarProxy::GetRange(unsigned int p_nIndex) const
{
	if (p_nIndex >= PLAYER_SONAR_MAX_SAMPLES)
		return 0;

	return m_arrRanges[p_nIndex];
}

void SonarProxy::FillData(player_msghdr_t hdr, const char* buffer)
{
	if (hdr.size != sizeof(player_sonar_data_t))
		return;

	memset(m_arrRanges, 0, sizeof(m_arrRanges));

	player_sonar_data_t* msg = (player_sonar_data_t*)buffer;
	m_nRangeCount = ntohs(msg->range_count);

	printf("Range count = %d\n", m_nRangeCount);

	// Sanity check
	if (m_nRangeCount > PLAYER_SONAR_MAX_SAMPLES)
		m_nRangeCount = PLAYER_SONAR_MAX_SAMPLES;

	for (int nIndex = 0; nIndex < m_nRangeCount; nIndex++)
	{
		m_arrRanges[nIndex] = ntohs(msg->ranges[nIndex]);
	}
}

void SonarProxy::Print()
{
	printf("#Sonar(%d:%d) - %c\n", GetDevice(), GetIndex(), GetAccess());
	for (int nIndex = 0; nIndex < m_nRangeCount; nIndex++)
		printf("%u\n", m_arrRanges[nIndex]);
}