/*
 *  Player - One Hell of a Robot Server
 *  Copyright (C) 2000  
 *     Brian Gerkey, Kasper Stoy, Richard Vaughan, & Andrew Howard
 *                      
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

/*
 * $Id: playercommon.h,v 1.2 2003/03/03 16:26:12 jkdoug Exp $
 * 
 * common standard types and some generic size stuff.
 * also, debugging stuff.
 *
 * Windows port by Jason K. Douglas, ARL/PSU
 */

#ifndef _PLAYERCOMMON_H
#define _PLAYERCOMMON_H

/* make sure we get the various types like 'uint8_t' */
#define int8_t char
#define int16_t short
#define int32_t long
#define int64_t __int64

#define uint8_t unsigned char
#define uint16_t unsigned short
#define uint32_t unsigned long
#define uing64_t unsigned __int64

#define MAX_FILENAME_SIZE 256 // space for a relatively long pathname

////////////////////////////////////////////////////////////////////////////////
// Maths stuff

#ifndef M_PI
#	define M_PI        3.14159265358979323846
#endif

// Convert radians to degrees
//
#define RTOD(r) ((r) * 180 / M_PI)

// Convert degrees to radians
//
#define DTOR(d) ((d) * M_PI / 180)

// Normalize angle to domain -pi, pi
//
#define NORMALIZE(z) atan2(sin(z), cos(z))

#define MAKEUINT16(lo, hi) ((((uint16_t) (hi)) << 8) | ((uint16_t) (lo)))

#ifndef BOOL
#	define BOOL int
#endif

#ifndef TRUE
#	define TRUE true
#endif

#ifndef FALSE
#	define FALSE false
#endif

////////////////////////////////////////////////////////////////////////////////
// Array checking macros

// Macro for returning array size
//
#ifndef ARRAYSIZE
	// Note that the cast to int is used to suppress warning about
	// signed/unsigned mismatches.
#	define ARRAYSIZE(x) (int) (sizeof(x) / sizeof(x[0]))
#endif

// Macro for checking array bounds
//
#define ASSERT_INDEX(index, array) \
    ASSERT((size_t) (index) >= 0 && (size_t) (index) < sizeof(array) / sizeof(array[0]));



////////////////////////////////////////////////////////////////////////////////
// Error, msg, trace macros

#ifndef WIN32
#	include <assert.h>

#	define ASSERT(m) assert(m)
#	define VERIFY(m) assert(m)
#endif

#include <stdio.h>

/* too noisy! */
#define PLAYER_ERROR(m)         printf("error : %s %d\n        "m"\n", __FILE__, __LINE__)
#define PLAYER_ERROR1(m, a)     printf("error : %s %d\n        "m"\n", __FILE__, __LINE__, a)
#define PLAYER_ERROR2(m, a, b)  printf("error : %s %d\n        "m"\n", __FILE__, __LINE__, a, b)
//#define PLAYER_ERROR(m) 


#if PLAYER_ENABLE_MSG

#define PLAYER_MSG0(m)             printf("msg   : %s %d\n        "m"\n", \
                                          __FILE__, __LINE__)   
#define PLAYER_MSG1(m, a)          printf("msg   : %s %d\n        "m"\n", \
                                          __FILE__, __LINE__, a)
#define PLAYER_MSG2(m, a, b)       printf("msg   : %s %d\m        "m"\n", \
                                          __FILE__, __LINE__, a, b)
#define PLAYER_MSG3(m, a, b, c)    printf("msg   : %s %d\n        "m"\n", \
                                          __FILE__, __LINE__, a, b, c) 
#define PLAYER_MSG4(m, a, b, c, d) printf("msg   : %s %d\n        "m"\n", \
                                          __FILE__, __LINE__, a, b, c, d)
#else

#define PLAYER_MSG0(m)
#define PLAYER_MSG1(m, a)
#define PLAYER_MSG2(m, a, b)
#define PLAYER_MSG3(m, a, b, c)
#define PLAYER_MSG4(m, a, b, c, d)

#endif

#if PLAYER_ENABLE_TRACE

#define PLAYER_TRACE0(m)             printf("debug : %s %d\n        "m"\n", \
                                            __FILE__, __LINE__) 
#define PLAYER_TRACE1(m, a)          printf("debug : %s %d\n        "m"\n", \
                                            __FILE__, __LINE__, a)
#define PLAYER_TRACE2(m, a, b)       printf("debug : %s %d\n        "m"\n", \
                                            __FILE__, __LINE__, a, b)
#define PLAYER_TRACE3(m, a, b, c)    printf("debug : %s %d\n        "m"\n", \
                                            __FILE__, __LINE__, a, b, c)
#define PLAYER_TRACE4(m, a, b, c, d) printf("debug : %s %d\n        "m"\n", \
                                            __FILE__, __LINE__, a, b, c, d)

#else

#define PLAYER_TRACE0(m)
#define PLAYER_TRACE1(m, a)
#define PLAYER_TRACE2(m, a, b)
#define PLAYER_TRACE3(m, a, b, c)
#define PLAYER_TRACE4(m, a, b, c, d)

#endif



#endif
