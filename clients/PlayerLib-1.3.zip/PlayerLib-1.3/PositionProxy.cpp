// PlayerLib - A Win32 client library for Player
// Copyright (C) 2001,2002
//    Jason K. Douglas, Applied Research Labs, Penn State University
//
//
// Based entirely on:
//   Player - One Hell of a Robot Server
//   Copyright (C) 2000  
//      Brian Gerkey, Kasper Stoy, Richard Vaughan, & Andrew Howard
//                     
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
///////////////////////////////////////


#include "PositionProxy.h"
#include "PlayerClient.h"

PositionProxy::PositionProxy(PlayerClient* p_pClient, unsigned short p_nIndex,
							 unsigned char p_chReqAccess)
: ClientProxy(p_pClient, PLAYER_POSITION_CODE, p_nIndex, p_chReqAccess)
{

}

PositionProxy::~PositionProxy()
{

}

int PositionProxy::SetSpeed(long p_nSpeed, long p_nTurnRate, long p_nSideSpeed)
{
	if (!m_pClient)
		return -1;

	player_position_cmd_t cmd;
	memset(&cmd, 0, sizeof(cmd));

	cmd.xspeed = htonl(p_nSpeed);
	cmd.yspeed = htonl(p_nSideSpeed);
	cmd.yawspeed = htonl(p_nTurnRate);

	return m_pClient->Write(PLAYER_POSITION_CODE, GetIndex(), (const char*)&cmd, sizeof(cmd));
}

// Sets the desired heading to theta, with the translational
//	and rotational velocity contraints xspeed and yawspeed, respectively
int PositionProxy::DoDesiredHeading(long p_nTheta, long p_nSpeed, long p_nTurnRate)
{
	if (!m_pClient)
		return -1;

	player_position_cmd_t cmd;
	memset(&cmd, 0, sizeof(cmd));

	// the desired heading is the yaw member
	cmd.yaw = htonl(p_nTheta);

	// set velocity constraints
	cmd.xspeed = htonl(p_nSpeed);
	cmd.yawspeed = htonl(p_nTurnRate);

	return m_pClient->Write(PLAYER_POSITION_CODE, GetIndex(), (const char *)&cmd, sizeof(cmd));
}

// If the robot is in position mode, this will make it perform
//	a straight line translation by trans mm. (negative values will be backwards)
//	undefined effect if in velocity mode
int PositionProxy::DoStraightLine(long p_nTranslation)
{
	if (!m_pClient)
		return -1;

	player_position_cmd_t cmd;
	memset(&cmd, 0, sizeof(cmd));

	// HACK: We send a no movement pos command first so that 
	// the real pos command will look new.
	cmd.xspeed = 0;
	cmd.yawspeed = 0;
	cmd.yaw = 0;

	m_pClient->Write(PLAYER_POSITION_CODE, GetIndex(), (const char *)&cmd, sizeof(cmd));

	// Now, we send the real pos command
	cmd.xspeed = htonl(p_nTranslation);

	return m_pClient->Write(PLAYER_POSITION_CODE, GetIndex(), (const char *)&cmd, sizeof(cmd));
}

// If in position mode, this will cause a turn in place rotation of
//	rot degrees. Undefined effect in velocity mode.
int PositionProxy::DoRotation(long p_nRotation)
{
	if (!m_pClient)
		return -1;

	player_position_cmd_t cmd;
	memset(&cmd, 0, sizeof(cmd));

	// HACK: Send a fake pos command first so the
	// real one will be flagged as new
	cmd.xspeed = 0;
	cmd.yawspeed = 0;
	cmd.yaw = 0;

	m_pClient->Write(PLAYER_POSITION_CODE, GetIndex(), (const char *)&cmd, sizeof(cmd));

	cmd.yawspeed = htonl(p_nRotation);

	return m_pClient->Write(PLAYER_POSITION_CODE, GetIndex(), (const char *)&cmd, sizeof(cmd));
}

int PositionProxy::SetMotorState(bool p_bEnabled)
{
	if (!m_pClient)
		return -1;

	player_position_power_config_t config;
	memset(&config, 0, sizeof(config));

	config.request = PLAYER_POSITION_MOTOR_POWER_REQ;
	config.value = p_bEnabled?1:0;

	return m_pClient->Request(PLAYER_POSITION_CODE, GetIndex(), (const char*)&config, sizeof(config));
}

int PositionProxy::SetVelocityControl(unsigned char p_nMode)
{
	if (!m_pClient)
		return -1;

	player_position_velocitymode_config_t config;
	memset(&config, 0, sizeof(config));

	config.request = PLAYER_POSITION_VELOCITY_MODE_REQ;
	config.value = p_nMode;

	return m_pClient->Request(PLAYER_POSITION_CODE, GetIndex(), (const char*)&config, sizeof(config));
}

int PositionProxy::SetPositionMode(unsigned char p_nMode)
{
	if (!m_pClient)
		return -1;

	player_position_position_mode_req_t req;
	memset(&req, 0, sizeof(req));

	req.subtype = PLAYER_POSITION_POSITION_MODE_REQ;
	req.state = p_nMode;

	return m_pClient->Request(PLAYER_POSITION_CODE, GetIndex(), (const char *)&req, sizeof(req));
}

int PositionProxy::ResetOdometry()
{
	if (!m_pClient)
		return -1;

	player_position_resetodom_config_t config;
	memset(&config, 0, sizeof(config));

	config.request = PLAYER_POSITION_RESET_ODOM_REQ;

	return m_pClient->Request(PLAYER_POSITION_CODE, GetIndex(), (const char*)&config, sizeof(config));
}

int PositionProxy::SetOdometry(long p_nXPos, long p_nYPos, unsigned short p_nTheta)
{
	if (!m_pClient)
		return -1;

	player_position_set_odom_req_t config;
	memset(&config, 0, sizeof(config));

	config.subtype = PLAYER_POSITION_SET_ODOM_REQ;
	config.x = htonl(p_nXPos);
	config.y = htonl(p_nYPos);
	config.theta = htons(p_nTheta);

	return m_pClient->Request(PLAYER_POSITION_CODE, GetIndex(), (const char*)&config, sizeof(config));
}

// Go to the specified location (x mm, y mm, t degrees).
//	This only works if the robot supports position control.
int PositionProxy::GoTo(long p_nXPos, long p_nYPos, long p_nTheta)
{
	if (!m_pClient)
		return -1;

	player_position_cmd_t cmd;
	memset(&cmd, 0, sizeof(cmd));

	cmd.xpos = htonl(p_nXPos);
	cmd.ypos = htonl(p_nYPos);
	cmd.yaw  = htonl(p_nTheta);

	return m_pClient->Write(PLAYER_POSITION_CODE, GetIndex(), (const char*)&cmd, sizeof(cmd));
}

// Set the PID for the speed controller
int PositionProxy::SetSpeedPID(unsigned long p_nKP, unsigned long p_nKI, unsigned long p_nKD)
{
	if (!m_pClient)
		return -1;

	player_position_speed_pid_req_t req;
	memset(&req, 0, sizeof(req));

	req.subtype = PLAYER_POSITION_SPEED_PID_REQ;
	req.kp = htonl(p_nKP);
	req.ki = htonl(p_nKI);
	req.kd = htonl(p_nKD);

	return m_pClient->Request(PLAYER_POSITION_CODE, GetIndex(), (const char *)&req, sizeof(req));
}

// Set the constants for the position PID
int PositionProxy::SetPositionPID(unsigned long p_nKP, unsigned long p_nKI, unsigned long p_nKD)
{
	if (!m_pClient)
		return -1;

	player_position_position_pid_req_t req;
	memset(&req, 0, sizeof(req));

	req.subtype = PLAYER_POSITION_POSITION_PID_REQ;
	req.kp = htonl(p_nKP);
	req.ki = htonl(p_nKI);
	req.kd = htonl(p_nKD);

	return m_pClient->Request(PLAYER_POSITION_CODE, GetIndex(), (const char *)&req, sizeof(req));
}

// Set the speed profile values used during position mode
//	p_nSpeed is max speed in mm/s
//	p_nAcceleration is acceleration to use in mm/s^2
int PositionProxy::SetPositionSpeedProfile(short p_nSpeed, short p_nAcceleration)
{
	if (!m_pClient)
		return -1;

	player_position_speed_prof_req_t req;
	memset(&req, 0, sizeof(req));

	req.subtype = PLAYER_POSITION_SPEED_PROF_REQ;
	req.speed = htons(p_nSpeed);
	req.acc = htons(p_nAcceleration);

	return m_pClient->Request(PLAYER_POSITION_CODE, GetIndex(), (const char *)&req, sizeof(req));
}

void PositionProxy::FillData(player_msghdr_t hdr, const char* buffer)
{
	if (hdr.size != sizeof(player_position_data_t))
		return;

	player_position_data_t* pData = (player_position_data_t*)buffer;

	m_nXPos = ntohl(pData->xpos);
	m_nYPos = ntohl(pData->ypos);
	m_nTheta = ntohl(pData->yaw);
	m_nSpeed = ntohl(pData->xspeed);
	m_nSideSpeed = ntohl(pData->yspeed);
	m_nTurnRate = ntohl(pData->yawspeed);
	m_nStalls = pData->stall;
}

void PositionProxy::Print()
{
	printf("#Position(%d:%d) = %c\n", GetDevice(), GetIndex(), GetAccess());
	printf("#xpos\typos\ttheta\tspeed\tsidespeed\tturn\tstalls\n");
	printf("%d\t%d\t%u\t%d\t%d\t%d\t%d\n",
		   GetXPos(), GetYPos(), GetTheta(), GetSpeed(), GetSideSpeed(), GetTurnRate(), GetStalls());
}
