// PlayerLib - A Win32 client library for Player
// Copyright (C) 2001,2002
//    Jason K. Douglas, Applied Research Labs, Penn State University
//
//
// Based entirely on:
//   Player - One Hell of a Robot Server
//   Copyright (C) 2000  
//      Brian Gerkey, Kasper Stoy, Richard Vaughan, & Andrew Howard
//                     
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
///////////////////////////////////////


#include "GripperProxy.h"
#include "PlayerClient.h"

GripperProxy::GripperProxy(PlayerClient* p_pClient, unsigned short p_nIndex,
						   unsigned char p_chReqAccess)
: ClientProxy(p_pClient, PLAYER_GRIPPER_CODE, p_nIndex, p_chReqAccess)
{

}

GripperProxy::~GripperProxy()
{

}

int GripperProxy::SetGrip(unsigned char p_chCmd, unsigned char p_chArg)
{
	if (!m_pClient)
		return -1;

	player_gripper_cmd_t cmd;

	cmd.cmd = p_chCmd;
	cmd.arg = p_chArg;

	// Write command to the robot
	int nRet = m_pClient->Write(PLAYER_GRIPPER_CODE, GetIndex(), (const char*)&cmd, sizeof(cmd));

	// HACK: should update the Player packet for new P2OS flags
	// If the command was successful, update internal flags
	if (nRet != -1)
	{
		m_bGripperError = false;
		m_bLiftError = false;

		switch (p_chCmd)
		{
			case GRIPopen:
				m_bPaddlesClosed = false;
				m_bPaddlesOpen = true;
				break;

			case GRIPclose:
				m_bPaddlesClosed = true;
				m_bPaddlesOpen = false;
				break;

			case LIFTup:
				m_bLiftUp = true;
				m_bLiftDown = false;
				break;

			case LIFTdown:
				m_bLiftUp = false;
				m_bLiftDown = true;
				break;

			default:
				break;
		}
	}
	// Handle errors
	else
	{
		switch (p_chCmd)
		{
			case GRIPopen:
			case GRIPclose:
				m_bGripperError = true;
				break;

			case LIFTup:
			case LIFTdown:
				m_bLiftError = true;
				break;

			default:
				break;
		}
	}

	return nRet;
}

void GripperProxy::FillData(player_msghdr_t hdr, const char* buffer)
{
	//if (hdr.size != sizeof(player_gripper_data_t))
	//	return;

	//player_gripper_data_t* pData = (player_gripper_data_t*)buffer;

	//m_chState = pData->state;
	//m_chBeams = pData->beams;

	//m_bOuterBreakBeam = (m_chBeams & 0x04)?true:false;
	//m_bInnerBreakBeam = (m_chBeams & 0x08)?true:false;

	//m_bPaddlesOpen = (m_chState & 0x01)?true:false;
	//m_bPaddlesClosed = (m_chState & 0x02)?true:false;
	//m_bPaddlesMoving = (m_chState & 0x04)?true:false;

	//m_bGripperError = (m_chState & 0x08)?true:false;

	//m_bLiftUp = (m_chState & 0x10)?true:false;
	//m_bLiftDown = (m_chState & 0x20)?true:false;
	//m_bLiftMoving = (m_chState & 0x40)?true:false;
	//m_bLiftError = (m_chState & 0x80)?true:false;
}

void GripperProxy::Print()
{
	printf("#Gripper(%d:%d) - %c\n", GetDevice(), GetIndex(), GetAccess());
	printf("#paddles\tinner beams\touter beams\n");
	printf("%s\t%s\t%s\n", m_bPaddlesOpen?"open":"close",
		   m_bInnerBreakBeam?"broken":"clear", m_bOuterBreakBeam?"broken":"clear");
}
