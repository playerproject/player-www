// PlayerLib - A Win32 client library for Player
// Copyright (C) 2001,2002
//    Jason K. Douglas, Applied Research Labs, Penn State University
//
//
// Based entirely on:
//   Player - One Hell of a Robot Server
//   Copyright (C) 2000  
//      Brian Gerkey, Kasper Stoy, Richard Vaughan, & Andrew Howard
//                     
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
///////////////////////////////////////


#include "BlobFinderProxy.h"

Blob::Blob()
{
	color = area = x = y = left = right = top = bottom = 0;
}

Blob::~Blob()
{

}

BlobFinderProxy::BlobFinderProxy(PlayerClient* p_pClient, unsigned short p_nIndex,
						 unsigned char p_chReqAccess)
: ClientProxy(p_pClient, PLAYER_BLOBFINDER_CODE, p_nIndex, p_chReqAccess)
{
	memset(m_nBlobs, 0, sizeof(m_nBlobs));
	memset(m_arrBlobs, NULL, sizeof(m_arrBlobs));
}

BlobFinderProxy::~BlobFinderProxy()
{
}

unsigned short BlobFinderProxy::GetNumBlobs(unsigned int p_nChannel) const
{
	if (p_nChannel < PLAYER_BLOBFINDER_MAX_CHANNELS)
		return m_nBlobs[p_nChannel];

	return 0;
}

Blob BlobFinderProxy::GetBlob(unsigned int p_nChannel, unsigned int p_nBlob) const
{
	if (p_nChannel < PLAYER_BLOBFINDER_MAX_CHANNELS && p_nBlob < PLAYER_BLOBFINDER_MAX_BLOBS_PER_CHANNEL)
		return m_arrBlobs[p_nChannel][p_nBlob];

	return Blob();
}

void BlobFinderProxy::FillData(player_msghdr_t hdr, const char* buffer)
{
	try
	{
		if (hdr.size > sizeof(player_blobfinder_data_t))
			return;

		player_blobfinder_data_t* msg = (player_blobfinder_data_t*)buffer;

		m_nWidth = ntohs(msg->width);
		m_nHeight = ntohs(msg->height);

		for (int channel = 0; channel < PLAYER_BLOBFINDER_MAX_CHANNELS; channel++)
		{
			m_nBlobs[channel] = ntohs(msg->header[channel].num);
			if (m_nBlobs[channel] < 0)
				m_nBlobs[channel] = 0;

			int index = ntohs(msg->header[channel].index);

			for (int blob = 0; blob < m_nBlobs[channel]; blob++)
			{
				m_arrBlobs[channel][blob].color = ntohl(msg->blobs[index + blob].color);
				m_arrBlobs[channel][blob].area = ntohl(msg->blobs[index + blob].area);
				m_arrBlobs[channel][blob].x = ntohs(msg->blobs[index + blob].x);
				m_arrBlobs[channel][blob].y = ntohs(msg->blobs[index + blob].y);
				m_arrBlobs[channel][blob].left = ntohs(msg->blobs[index + blob].left);
				m_arrBlobs[channel][blob].right = ntohs(msg->blobs[index + blob].right);
				m_arrBlobs[channel][blob].top = ntohs(msg->blobs[index + blob].top);
				m_arrBlobs[channel][blob].bottom = ntohs(msg->blobs[index + blob].bottom);
				m_arrBlobs[channel][blob].range = ntohs(msg->blobs[index + blob].range);
			}
		}
	}
	catch (...)
	{
		// Unknown exception
	}
}

void BlobFinderProxy::Print()
{
	printf("#Vision(%d:%d) - %c\n", GetDevice(), GetIndex(), GetAccess());
	for (int nChannel = 0; nChannel < PLAYER_BLOBFINDER_MAX_CHANNELS; nChannel++)
	{
		if (m_nBlobs[nChannel])
		{
			printf("#Channel %d:\n", nChannel);
			for (int nBlob = 0; nBlob < m_nBlobs[nChannel]; nBlob++)
			{
				printf("  blob %d:\n"
					   "    color: %d\n"
					   "     area: %d\n"
					   "      xcg: %d\n"
					   "      ycg: %d\n"
					   "     left: %d\n"
					   "    right: %d\n"
					   "      top: %d\n"
					   "   bottom: %d\n",
					   nBlob + 1,
					   m_arrBlobs[nChannel][nBlob].color,
					   m_arrBlobs[nChannel][nBlob].area,
					   m_arrBlobs[nChannel][nBlob].x,
					   m_arrBlobs[nChannel][nBlob].y,
					   m_arrBlobs[nChannel][nBlob].left,
					   m_arrBlobs[nChannel][nBlob].right,
					   m_arrBlobs[nChannel][nBlob].top,
					   m_arrBlobs[nChannel][nBlob].bottom);
			}
		}
	}
}