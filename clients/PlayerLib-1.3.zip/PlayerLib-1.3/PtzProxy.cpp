// PlayerLib - A Win32 client library for Player
// Copyright (C) 2001,2002
//    Jason K. Douglas, Applied Research Labs, Penn State University
//
//
// Based entirely on:
//   Player - One Hell of a Robot Server
//   Copyright (C) 2000  
//      Brian Gerkey, Kasper Stoy, Richard Vaughan, & Andrew Howard
//                     
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
///////////////////////////////////////


#include "PtzProxy.h"
#include "PlayerClient.h"

PtzProxy::PtzProxy(PlayerClient* pClient, unsigned short nIndex, unsigned char chAccess)
: ClientProxy(pClient, PLAYER_PTZ_CODE, nIndex, chAccess)
{

}

PtzProxy::~PtzProxy()
{

}

// send a camera command
//
// Returns:
//   0 if everything's ok
//   -1 otherwise (that's bad)
int PtzProxy::SetCam(short nPan, short nTilt, unsigned short nZoom)
{
	if (!m_pClient)
		return -1;

	m_nPan = nPan;
	m_nTilt = nTilt;
	m_nZoom = nZoom;
	
	player_ptz_cmd_t cmd;
	
	cmd.pan = htons(nPan);
	cmd.tilt = htons(nTilt);
	cmd.zoom = htons(nZoom);
	
	return m_pClient->Write(PLAYER_PTZ_CODE, GetIndex(), (const char*)&cmd, sizeof(cmd));
}

void PtzProxy::FillData(player_msghdr_t hdr, const char* buffer)
{
	if (hdr.size != sizeof(player_ptz_data_t))
		return;

	player_ptz_data_t* msg = (player_ptz_data_t*)buffer;

	m_nPan = ntohs(msg->pan);
	m_nTilt = ntohs(msg->tilt);
	m_nZoom = ntohs(msg->zoom);
}

// interface that all proxies SHOULD provide
void PtzProxy::Print()
{
	printf("#Ptz(%d:%d) - %c\n", GetDevice(), GetIndex(), GetAccess());
	puts("#pan\ttilt\tzoom");
	printf("%d\t%d\t%u\n", GetPan(), GetTilt(), GetZoom());
}

