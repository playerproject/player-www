// PlayerLib - A Win32 client library for Player
// Copyright (C) 2001,2002
//    Jason K. Douglas, Applied Research Labs, Penn State University
//
//
// Based entirely on:
//   Player - One Hell of a Robot Server
//   Copyright (C) 2000  
//      Brian Gerkey, Kasper Stoy, Richard Vaughan, & Andrew Howard
//                     
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
///////////////////////////////////////
//
// Class: SonarProxy
// Description:
//	Reads front and rear sonar data.
//
// Change List:
// 
//	Date	Initials	Description
// ------  ----------  -------------------------------------------------------
// 020319	jkd			Initial version.
//
///////////////////////////////////////


#if !defined(AFX_SONARPROXY_H__7F95680F_EBBE_460B_8ECE_425579494C09__INCLUDED_)
#define AFX_SONARPROXY_H__7F95680F_EBBE_460B_8ECE_425579494C09__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "PlayerLib.h"
#include "ClientProxy.h"

class PLAYERLIB_API SonarProxy : public ClientProxy  
{
public:
	SonarProxy(PlayerClient* p_pClient, unsigned short p_nIndex = 0,
			   unsigned char p_chReqAccess = 'r');
	virtual ~SonarProxy();

	virtual int SetSonarState(bool p_bOn);

	virtual unsigned short operator [](unsigned int p_nIndex);

	virtual int GetSonarPose();
	virtual unsigned short GetRange(unsigned int p_nIndex) const;

	virtual void FillData(player_msghdr_t hdr, const char* buffer);
	virtual void Print();

protected:
	unsigned short m_nRangeCount;
	unsigned short m_arrRanges[PLAYER_SONAR_MAX_SAMPLES];
public:
	player_sonar_geom_t m_SonarPose;
};

#endif // !defined(AFX_SONARPROXY_H__7F95680F_EBBE_460B_8ECE_425579494C09__INCLUDED_)
