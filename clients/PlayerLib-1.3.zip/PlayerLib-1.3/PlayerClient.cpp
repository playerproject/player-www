// PlayerLib - A Win32 client library for Player
// Copyright (C) 2001,2002
//    Jason K. Douglas, Applied Research Labs, Penn State University
//
//
// Based entirely on:
//   Player - One Hell of a Robot Server
//   Copyright (C) 2000  
//      Brian Gerkey, Kasper Stoy, Richard Vaughan, & Andrew Howard
//                     
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
///////////////////////////////////////


#include "PlayerClient.h"
#include "ClientProxy.h"

PlayerClient::PlayerClient(const char* p_strHostname, int p_nPort)
{
	m_pProxies = NULL;
	m_nProxies = 0;

	m_bDestroyed = false;
	m_bFresh = false;

	strcpy(m_strHostname, "");
	m_nPort = 0;

	m_nReserved = 0;

	m_chDataMode = PLAYER_DATAMODE_PUSH_ALL;

	if (p_strHostname)
	{
		if (Connect(p_strHostname, p_nPort))
		{
			// WARNING: unable to connect
		}
	}
}

PlayerClient::~PlayerClient()
{
	m_bDestroyed = true;

	Disconnect();

	m_pProxies = NULL;
}

int PlayerClient::CountReadProxies()
{
	int nCount = 0;
	ClientProxyNode* pNode = m_pProxies;

	while (pNode)
	{
		if (pNode->proxy && (pNode->proxy->GetAccess() == 'a' || pNode->proxy->GetAccess() == 'r'))
			nCount++;

		pNode = pNode->next;
	}

	return nCount;
}

ClientProxy* PlayerClient::GetProxy(unsigned short p_nDevice, unsigned short p_nIndex)
{
	ClientProxyNode* pNode = m_pProxies;

	while (pNode)
	{
		if (pNode->proxy && pNode->proxy->GetDevice() == p_nDevice && pNode->proxy->GetIndex() == p_nIndex)
			return pNode->proxy;

		pNode = pNode->next;
	}

	return NULL;
}

int PlayerClient::Connect(const char* p_strHostname, int p_nPort)
{
	Disconnect();

	if (!p_strHostname)
		return -1;

	strncpy(m_strHostname, p_strHostname, 255);
	m_nPort = p_nPort;

	return m_Connection.Connect(m_strHostname, m_nPort);
}

int PlayerClient::Disconnect()
{
	if (!m_bDestroyed)
	{
		ClientProxyNode* pNode = m_pProxies;
		while (pNode)
		{
			if (pNode->proxy)
				pNode->proxy->ChangeAccess('c');

			pNode = pNode->next;
		}
	}
	
	return m_Connection.Disconnect();
}

int PlayerClient::Read()
{
	// If we are pulling the data in request/reply mode, request a packet before reading
	if (GetDataMode() == PLAYER_DATAMODE_PULL_ALL || GetDataMode() == PLAYER_DATAMODE_PULL_NEW)
		RequestData();

	player_msghdr_t hdr;
	char buffer[PLAYER_MAX_MESSAGE_SIZE];
	struct timeval curr;
	ClientProxy* pProxy = NULL;

	// Can't read if you're not connected
	if (!IsConnected())
		return -1;

	// Read packets for each proxy connected
	for (int nReads = CountReadProxies(); nReads > 0; nReads--)
	{
		if (m_Connection.Read(&hdr, buffer, sizeof(buffer)))
		{
			m_bFresh = true;
			return -1;
		}
		gettimeofday(&curr, NULL);

		pProxy = GetProxy(hdr.device, hdr.device_index);
		if (!pProxy)
			continue;

		// Put the data in the object
		if (hdr.size)
			pProxy->FillData(hdr, buffer);

		// Fill in the timestamps
		pProxy->SetTimestamp(hdr.timestamp_sec, hdr.timestamp_usec);
		pProxy->SetSentTime(hdr.time_sec, hdr.time_usec);
		pProxy->SetReceivedTime(curr.tv_sec, curr.tv_usec);
	}

	return 0;
}

int PlayerClient::Write(unsigned short p_nDevice, unsigned short p_nIndex,
						const char* p_strCommand, size_t p_nCommandLen)
{
	// Can't write if you're not connected
	if (!IsConnected())
		return -1;

	return m_Connection.Write(p_nDevice, p_nIndex, p_strCommand, p_nCommandLen, GetReserved());
}

int PlayerClient::Request(unsigned short p_nDevice, unsigned short p_nIndex,
						  const char *p_strPayload, size_t p_nPayloadLen,
						  player_msghdr_t *p_pReplyHdr, char *p_strReply, size_t p_nReplyLen)
{
	// Can't request if you're not connected
	if (!IsConnected())
		return -1;

	return m_Connection.Request(p_nDevice, p_nIndex, p_strPayload, p_nPayloadLen, p_pReplyHdr, p_strReply, p_nReplyLen);
}

int PlayerClient::RequestDeviceAccess(unsigned short p_nDevice,
                        unsigned short p_nIndex,
                        unsigned char p_chReqAccess,
                        unsigned char* p_chGrantAccess,
                        char* p_strDriverName,
                        int p_nDriverNameLength)
{
	// Can't request device access if you're not connected
	if (!IsConnected())
		return -1;

	return m_Connection.RequestDeviceAccess(p_nDevice, p_nIndex, p_chReqAccess,
		p_chGrantAccess, p_strDriverName, p_nDriverNameLength);
}

int PlayerClient::SetFrequency(unsigned short p_nFrequency)
{
	//player_device_ioctl_t ioCtl;
	//player_device_datafreq_req_t req;
	//char strPayload[sizeof(ioCtl) + sizeof(req)];

	//ioCtl.subtype = htons(PLAYER_PLAYER_DATAFREQ_REQ);
	//req.frequency = htons(p_nFrequency);

	//memcpy(strPayload, &ioCtl, sizeof(ioCtl));
	//memcpy(strPayload + sizeof(ioCtl), &req, sizeof(req));

	//return Request(PLAYER_PLAYER_CODE, 0, strPayload, sizeof(strPayload));
	return 0;
}

int PlayerClient::SetDataMode(unsigned char p_chMode)
{
	m_chDataMode = p_chMode;

	//player_device_ioctl_t ioCtl;
	//player_device_datamode_req_t req;
	//char strPayload[sizeof(ioCtl) + sizeof(req)];

	//ioCtl.subtype = htons(PLAYER_PLAYER_DATAMODE_REQ);
	//req.mode = p_chMode;

	//memcpy(strPayload, &ioCtl, sizeof(ioCtl));
	//memcpy(strPayload + sizeof(ioCtl), &req, sizeof(req));

	//return Request(PLAYER_PLAYER_CODE, 0, strPayload, sizeof(strPayload));
	return 0;
}

int PlayerClient::RequestData()
{
	//player_device_ioctl_t ioCtl;

	//ioCtl.subtype = htons(PLAYER_PLAYER_DATA_REQ);

	//return Request(PLAYER_PLAYER_CODE, 0, (char*)&ioCtl, sizeof(ioCtl));
	return 0;
}

int PlayerClient::Authenticate(const char* p_strKey)
{
	//player_device_ioctl_t ioCtl;
	//player_device_auth_req_t req;
	//char strPayload[sizeof(ioCtl) + sizeof(req)];

	//ioCtl.subtype = htons(PLAYER_PLAYER_AUTH_REQ);
	//strncpy(req.auth_key, p_strKey, sizeof(req.auth_key));

	//memcpy(strPayload, &ioCtl, sizeof(ioCtl));
	//memcpy(strPayload + sizeof(ioCtl), &req, sizeof(req));

	//return Request(PLAYER_PLAYER_CODE, 0, strPayload, sizeof(strPayload));
	return 0;
}

void PlayerClient::AddProxy(ClientProxy* p_pProxy)
{
	if (!p_pProxy)
		return;

	// If the list is empty, start a new one
	if (!m_pProxies)
	{
		m_pProxies = new ClientProxyNode;
		if (!m_pProxies)
			return;

		m_pProxies->proxy = p_pProxy;
	}
	else
	{
		// Walk to the end of the list
		ClientProxyNode* pNode = m_pProxies;
		while (pNode->next)
			pNode = pNode->next;

		pNode->next = new ClientProxyNode;
		if (!pNode->next)
			return;

		pNode->next->proxy = p_pProxy;
	}

	m_nProxies++;
}

void PlayerClient::RemoveProxy(ClientProxy* p_pProxy)
{
	if (!p_pProxy)
		return;

	ClientProxyNode* pNode = m_pProxies;
	ClientProxyNode* pPrevNode = NULL;

	while (pNode)
	{
		if (pNode->proxy == p_pProxy)
		{
			if (pPrevNode)
				pPrevNode->next = pNode->next;
			else
				m_pProxies = NULL;

			delete pNode;
			m_nProxies--;

			return;
		}

		pPrevNode = pNode;
		pNode = pNode->next;
	}
}
