// PlayerLib.cpp : Defines the entry point for the DLL application.
//

#include "PlayerLib.h"

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
		case DLL_PROCESS_DETACH:
			break;
    }
    return TRUE;
}

PLAYERLIB_API int gettimeofday(struct timeval* tv, struct timezone* tz)
{
  static __int64 Adjustment = 0;
  __int64 Now = 0;
  
  if (!Adjustment)
  {
    SYSTEMTIME st = {1970,1,3,0,0,0,0};
    SystemTimeToFileTime(&st, (LPFILETIME)Adjustment);
  }
  
//  if (tz)
//  {
//    return -1;
//  }
  
  GetSystemTimeAsFileTime((LPFILETIME)&Now);
  Now -= Adjustment;
  
  tv->tv_sec = (long)(Now / 100000000);
  tv->tv_usec = (long)((Now / 100) - (((__int64)tv->tv_sec * 1000) * 100));
  return 0;
}
