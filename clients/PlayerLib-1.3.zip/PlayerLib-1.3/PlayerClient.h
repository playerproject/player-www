// PlayerLib - A Win32 client library for Player
// Copyright (C) 2001,2002
//    Jason K. Douglas, Applied Research Labs, Penn State University
//
//
// Based entirely on:
//   Player - One Hell of a Robot Server
//   Copyright (C) 2000  
//      Brian Gerkey, Kasper Stoy, Richard Vaughan, & Andrew Howard
//                     
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
///////////////////////////////////////
//
// Class: PlayerClient
// Description:
//	Parent of all connected devices.  Handles all proxy connections.
//
// Change List:
// 
//	Date	Initials	Description
// ------  ----------  -------------------------------------------------------
// 020319	jkd			Initial version.
//
///////////////////////////////////////


#if !defined(AFX_PLAYERCLIENT_H__6EE9E872_4333_4E59_8263_DC3180B6BE23__INCLUDED_)
#define AFX_PLAYERCLIENT_H__6EE9E872_4333_4E59_8263_DC3180B6BE23__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "PlayerLib.h"
#include "PlayerConnection.h"
#include "ClientProxy.h"

class PLAYERLIB_API PlayerClient  
{
public:
	PlayerClient(const char* p_strHostname = NULL, int p_nPort = PLAYER_PORTNUM);
	virtual ~PlayerClient();

private:
	// Count devices with access 'r' or 'a'
	int CountReadProxies();

	// Get the pointer to the proxy for the given device and index
	//	Returns NULL if not found.
	ClientProxy* GetProxy(unsigned short p_nDevice, unsigned short p_nIndex);

public:
	void SetReserved(int p_nReserved) { m_nReserved = p_nReserved; };
	int GetReserved() const { return m_nReserved; };

	// Three ways to connect to the server
	//	Returns -1 if there was an error connecting, 0 otherwise.
	int Connect(const char* p_strHostname, int p_nPort);
	int Connect(const char* p_strHostname) { return Connect(p_strHostname, PLAYER_PORTNUM); };
	int Connect() { return Connect("localhost", PLAYER_PORTNUM); };

	// Disconnect from the server
	//	Returns -1 if there was an error disconnecting, 0 otherwise.
	int Disconnect();

	// Are we connected?
	bool IsConnected() const { return m_Connection.IsConnected(); };

	// Have we been destroyed and disconnected?
	bool IsDestroyed() const { return m_bDestroyed; };

	// Is there new data waiting?
	bool IsFresh() const { return m_bFresh; };

	// Read from our connection, and put the data in the proper device object.
	//	Returns -1 if there was an error reading, 0 otherwise.
	int Read();

	// Write a message to our connection.
	//	Returns -1 if there was an error writing, 0 otherwise.
	int Write(unsigned short p_nDevice, unsigned short p_nIndex,
		      const char* p_strCommand, size_t p_nCommandLen);

	// Issue a request to the Player server
	int Request(unsigned short p_nDevice, unsigned short p_nIndex,
		        const char* p_strPayload, size_t p_nPayloadLen,
				player_msghdr_t* p_pReplyHdr, char* p_strReply, size_t p_nReplyLen);

	// Use this request method if you don't want a reply.
	int Request(unsigned short p_nDevice, unsigned short p_nIndex,
		        const char* p_strPayload, size_t p_nPayloadLen)
		{ return Request(p_nDevice, p_nIndex, p_strPayload, p_nPayloadLen, NULL, NULL, 0); };

	// Request access to a device; meant for client-side device proxy constructors.
	//
	//	p_chReqAccess is the requested access ('a', 'r', 'w', 'c')
	//	p_chGrantAccess, if non-NULL, will contain the granted access upon return
	//
	//	Returns -1 if there was an error accessing the device, 0 otherwise.
    int RequestDeviceAccess(unsigned short p_nDevice,
                            unsigned short p_nIndex,
                            unsigned char p_chReqAccess,
                            unsigned char* p_chGrantAccess,
                            char* p_strDriverName = NULL,
                            int p_nDriverNameLength = 0);


	// Player device configuration
	// ---------------------------

	// Change continuous data rate (frequency is in Hz)
	int SetFrequency(unsigned short p_nFrequency);

	// Change data delivery mode (0 = continuous (default); 1 = request/reply)
	int SetDataMode(unsigned char p_chMode);
	unsigned char GetDataMode() const { return m_chDataMode; };

	// Request a round of data (only valid when in request/reply mode)
	int RequestData();

	// Authenticate connection
	int Authenticate(const char* p_strKey);


	// Proxy list management methods
	// -----------------------------

	void AddProxy(ClientProxy* p_pProxy);
	void RemoveProxy(ClientProxy* p_pProxy);

protected:
	// Special flag to indicate that we are being destroyed
	bool m_bDestroyed;

	// List of proxies associated with us
	ClientProxyNode* m_pProxies;
	int m_nProxies;

	// Our connection to Player
	PlayerConnection m_Connection;

	int m_nReserved;

	unsigned char m_chDataMode;

	// Flag set if data has just been read into this device
	bool m_bFresh;

	// Store the name and port of the connected host
	char m_strHostname[256];
	int m_nPort;
};

#endif // !defined(AFX_PLAYERCLIENT_H__6EE9E872_4333_4E59_8263_DC3180B6BE23__INCLUDED_)
