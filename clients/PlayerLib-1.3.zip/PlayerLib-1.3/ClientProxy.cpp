// PlayerLib - A Win32 client library for Player
// Copyright (C) 2001,2002
//    Jason K. Douglas, Applied Research Labs, Penn State University
//
//
// Based entirely on:
//   Player - One Hell of a Robot Server
//   Copyright (C) 2000  
//      Brian Gerkey, Kasper Stoy, Richard Vaughan, & Andrew Howard
//                     
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
///////////////////////////////////////


#include "ClientProxy.h"
#include "PlayerClient.h"

ClientProxy::ClientProxy(PlayerClient* p_pClient,
						 unsigned short p_nReqDevice,
						 unsigned short p_nReqIndex,
						 unsigned char p_chReqAccess)
{
	m_nDevice = p_nReqDevice;
	m_nIndex = p_nReqIndex;
	strcpy(m_strDriverName, "");

	m_pClient = p_pClient;

	SetTimestamp(0, 0);
	SetSentTime(0, 0);
	SetReceivedTime(0, 0);

	unsigned char chGrantAccess = 'e';

	// add it to our client's list to manage
	if (m_pClient)
		m_pClient->AddProxy(this);

	if (m_pClient && p_chReqAccess != 'c')
		m_pClient->RequestDeviceAccess(p_nReqDevice, p_nReqIndex, p_chReqAccess,
		&chGrantAccess, m_strDriverName, sizeof(m_strDriverName));

	m_chAccess = chGrantAccess;
}

ClientProxy::~ClientProxy()
{
	if (m_pClient)
	{
//		if ((m_chAccess != 'c') && (m_chAccess != 'e'))
//			m_pClient->RequestDeviceAccess(m_nDevice, m_nIndex, 'c', NULL);

		m_pClient->RemoveProxy(this);
	}
}

void ClientProxy::SetTimestamp(long p_nSec, long p_nUSec)
{
	m_Timestamp.tv_sec = p_nSec;
	m_Timestamp.tv_usec = p_nUSec;
}

void ClientProxy::SetSentTime(long p_nSec, long p_nUSec)
{
	m_SentTime.tv_sec = p_nSec;
	m_SentTime.tv_usec = p_nUSec;
}

void ClientProxy::SetReceivedTime(long p_nSec, long p_nUSec)
{
	m_ReceivedTime.tv_sec = p_nSec;
	m_ReceivedTime.tv_usec = p_nUSec;
}

// Methods for changing access mode
int ClientProxy::ChangeAccess(unsigned char p_chReqAccess,
							  unsigned char* p_chGrantAccess)
{
	unsigned char chGrantAccess = m_chAccess;

	if (m_pClient)
	{
		if (m_pClient->RequestDeviceAccess(m_nDevice, m_nIndex, p_chReqAccess,
			&chGrantAccess, m_strDriverName, sizeof(m_strDriverName)))
			return -1;

		if (p_chReqAccess != chGrantAccess)
			return -1;
	}
	else
		return -1;

	m_chAccess = chGrantAccess;

	if (p_chGrantAccess)
		*p_chGrantAccess = m_chAccess;

	return 0;
}

// Interface that all proxies must provide
void ClientProxy::FillData(player_msghdr_t hdr, const char* buffer)
{
	// Just copy the data in a generic way
	memcpy(m_LastData, buffer, hdr.size);
	memcpy(&m_LastHeader, &hdr, sizeof(hdr));
}

// Interface that all proxies SHOULD provide
void ClientProxy::Print()
{
	// WARNING: ClientProxy::Print call is not valid
}
