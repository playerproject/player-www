// PlayerLib - A Win32 client library for Player
// Copyright (C) 2001,2002
//    Jason K. Douglas, Applied Research Labs, Penn State University
//
//
// Based entirely on:
//   Player - One Hell of a Robot Server
//   Copyright (C) 2000  
//      Brian Gerkey, Kasper Stoy, Richard Vaughan, & Andrew Howard
//                     
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
///////////////////////////////////////
//
// Class: PositionProxy
// Description:
//	Reads odometer data from robot controller and controls speed and heading.
//
// Change List:
// 
//	Date	Initials	Description
// ------  ----------  -------------------------------------------------------
// 020319	jkd			Initial version.
//
///////////////////////////////////////


#if !defined(AFX_POSITIONPROXY_H__B0C5056E_56AF_4F02_A635_1A92DC0AC6AA__INCLUDED_)
#define AFX_POSITIONPROXY_H__B0C5056E_56AF_4F02_A635_1A92DC0AC6AA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "PlayerLib.h"
#include "ClientProxy.h"

class PLAYERLIB_API PositionProxy : public ClientProxy  
{
public:
	PositionProxy(PlayerClient* p_pClient, unsigned short p_nIndex = 0,
				  unsigned char p_chReqAccess = 'a');
	virtual ~PositionProxy();

	virtual long GetXPos() const { return m_nXPos; };
	virtual long GetYPos() const { return m_nYPos; };
	virtual unsigned long GetTheta() const { return m_nTheta; };
	virtual long GetSpeed() const { return m_nSpeed; };
	virtual long GetSideSpeed() const { return m_nSideSpeed; };
	virtual long GetTurnRate() const { return m_nTurnRate; };
	virtual unsigned char GetStalls() const { return m_nStalls; };

	virtual int DoDesiredHeading(long p_nTheta, long p_nSpeed, long p_nTurnRate);
	virtual int DoStraightLine(long p_nTranslation);
	virtual int DoRotation(long p_nRotation);
	virtual int GoTo(long p_nXPos, long p_nYPos, long p_nTheta);

	virtual int SetSpeed(long p_nSpeed, long p_nTurnRate, long p_nSideSpeed = 0);
	virtual int SetSpeedPID(unsigned long p_nKP, unsigned long p_nKI, unsigned long p_nKD);
	virtual int SetPositionPID(unsigned long p_nKP, unsigned long p_nKI, unsigned long p_nKD);
	virtual int SetPositionSpeedProfile(short p_nSpeed, short p_nAcceleration);

	virtual int SetMotorState(bool p_bEnabled);

	// 0 = direct wheel velocity control (default)
	// 1 = separate translational and rotational control
	virtual int SetVelocityControl(unsigned char p_nMode);

	// Select the kind of velocity control to perform
	//	0 for velocity mode
	//	1 for position mode
	virtual int SetPositionMode(unsigned char p_nMode);

	// Reset the odometer to (0, 0, 0)
	virtual int ResetOdometry();
	virtual int SetOdometry(long p_nXPos, long p_nYPos, unsigned short p_nTheta);

	virtual void FillData(player_msghdr_t hdr, const char* buffer);

	virtual void Print();

private:
	long m_nXPos;
	long m_nYPos;
	unsigned long m_nTheta;
	long m_nSpeed;
	long m_nSideSpeed;
	long m_nTurnRate;
	unsigned char m_nStalls;
};

#endif // !defined(AFX_POSITIONPROXY_H__B0C5056E_56AF_4F02_A635_1A92DC0AC6AA__INCLUDED_)
