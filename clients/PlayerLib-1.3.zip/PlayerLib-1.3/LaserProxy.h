// PlayerLib - A Win32 client library for Player
// Copyright (C) 2001,2002
//    Jason K. Douglas, Applied Research Labs, Penn State University
//
//
// Based entirely on:
//   Player - One Hell of a Robot Server
//   Copyright (C) 2000  
//      Brian Gerkey, Kasper Stoy, Richard Vaughan, & Andrew Howard
//                     
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
///////////////////////////////////////
//
// Class: LaserProxy
// Description:
//	Reads distance measurements from laser rangefinder device.
//
// Change List:
// 
//	Date	Initials	Description
// ------  ----------  -------------------------------------------------------
// 020319	jkd			Initial version.
//
///////////////////////////////////////


#ifndef LASERPROXY_H
#define LASERPROXY_H

#include "PlayerLib.h"
#include "ClientProxy.h"

class PLAYERLIB_API LaserProxy : public ClientProxy
{
	
public:
    // the client calls this method to make a new proxy
    //   leave access empty to start unconnected
    LaserProxy(PlayerClient* p_pClient, unsigned short p_nIndex = 0, 
		unsigned char p_chAccess='r');

	virtual ~LaserProxy();
	
    // These methods are the user's interface to this device
	// ------------------
	
    // Configure the laser scan.
    virtual int Configure(short p_nMinAngle, short p_nMaxAngle, 
		unsigned short p_nResolution, bool p_bIntensity);
	
    // a different way to access the range data
    virtual unsigned short operator [](unsigned int p_nIndex)
    { 
		if (p_nIndex < sizeof(m_arrRanges))
			return m_arrRanges[p_nIndex];

		return 0;
    }
    
	virtual int GetConfigure();

	virtual unsigned short GetRange(unsigned int p_nIndex) const;
	virtual unsigned char GetIntensity(unsigned int p_nIndex) const;
	virtual bool GetIntensity() const { return m_bIntensity; };

	virtual unsigned short GetMinRight() const { return m_nMinRight; };
	virtual unsigned short GetMinLeft() const { return m_nMinLeft; };

	virtual short GetMinAngle() const { return m_nMinAngle; };
	virtual short GetMaxAngle() const { return m_nMaxAngle; };

	virtual unsigned short GetRangeCount() const { return m_nRangeCount; };
	virtual unsigned short GetResolution() const { return m_nResolution; };

    // interface that all proxies must provide
    virtual void FillData(player_msghdr_t hdr, const char* buffer);
    
    // interface that all proxies SHOULD provide
    virtual void Print();
	
protected:
    // the latest laser scan data
    short m_nMinAngle;
    short m_nMaxAngle;
    unsigned short m_nResolution;
    unsigned short m_nRangeCount;
    unsigned short m_arrRanges[PLAYER_LASER_MAX_SAMPLES];
    unsigned char m_arrIntensities[PLAYER_LASER_MAX_SAMPLES];
	bool m_bIntensity;
    unsigned short m_nMinRight;
	unsigned short m_nMinLeft;
	
};

#endif
