// PlayerLib - A Win32 client library for Player
// Copyright (C) 2001,2002
//    Jason K. Douglas, Applied Research Labs, Penn State University
//
//
// Based entirely on:
//   Player - One Hell of a Robot Server
//   Copyright (C) 2000  
//      Brian Gerkey, Kasper Stoy, Richard Vaughan, & Andrew Howard
//                     
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
///////////////////////////////////////
//
// Class: ClientProxy (and ClientProxyNode)
// Description:
//	Base class for all device proxy classes.  Provides common interface as
//	well as basic functionality for connecting to robot devices.
//
// Change List:
// 
//	Date	Initials	Description
// ------  ----------  -------------------------------------------------------
// 020319	jkd			Initial version.
//
///////////////////////////////////////


#if !defined(AFX_CLIENTPROXY_H__E8AB6FBD_0789_489D_8694_DD4EBA0699B9__INCLUDED_)
#define AFX_CLIENTPROXY_H__E8AB6FBD_0789_489D_8694_DD4EBA0699B9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "PlayerLib.h"

class PlayerClient;

class PLAYERLIB_API ClientProxy  
{
public:
	ClientProxy(PlayerClient* p_pClient,
			    unsigned short p_nReqDevice,
				unsigned short p_nReqIndex,
				unsigned char p_chReqAccess = 'c');
	virtual ~ClientProxy();

	void SetTimestamp(long p_nSec, long p_nUSec);
	void SetSentTime(long p_nSec, long p_nUSec);
	void SetReceivedTime(long p_nSec, long p_nUSec);

    unsigned char GetAccess() const { return m_chAccess; };
	unsigned short GetDevice() const { return m_nDevice; };
	unsigned short GetIndex() const { return m_nIndex; };
	const char* GetDriverName() const { return m_strDriverName; };

    // Methods for changing access mode
    int ChangeAccess(unsigned char p_chReqAccess, 
                     unsigned char* p_chGrantAccess = NULL);
    int Close() { return ChangeAccess('c'); }

    // Interface that all proxies must provide
    virtual void FillData(player_msghdr_t hdr, const char* buffer) = 0;
    
    // Interface that all proxies SHOULD provide
    virtual void Print();

protected:
    struct timeval m_Timestamp;		// time at which this data was sensed
    struct timeval m_SentTime;		// time at which this data was sent
    struct timeval m_ReceivedTime;	// time at which this data was received

	unsigned char m_chAccess;
	unsigned short m_nDevice;
	unsigned short m_nIndex;

	// The name of the driver used to implement this device in the server.
    char m_strDriverName[PLAYER_MAX_DEVICE_STRING_LEN];

    // If this generic proxy is not subclassed, the most recent 
    // data and header get copied in here. That way we can use this
    // base class on its own as a generic proxy.
    unsigned char m_LastData[PLAYER_MAX_MESSAGE_SIZE];
    player_msghdr_t m_LastHeader;

	PlayerClient* m_pClient;
};

class PLAYERLIB_API ClientProxyNode
{
public:
	ClientProxyNode() { proxy = NULL; next = NULL; };
	virtual ~ClientProxyNode() { };

	ClientProxy* proxy;
	ClientProxyNode* next;
};

#endif // !defined(AFX_CLIENTPROXY_H__E8AB6FBD_0789_489D_8694_DD4EBA0699B9__INCLUDED_)
