// PlayerLib - A Win32 client library for Player
// Copyright (C) 2001,2002
//    Jason K. Douglas, Applied Research Labs, Penn State University
//
//
// Based entirely on:
//   Player - One Hell of a Robot Server
//   Copyright (C) 2000  
//      Brian Gerkey, Kasper Stoy, Richard Vaughan, & Andrew Howard
//                     
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
///////////////////////////////////////


#include "LaserProxy.h"
#include "PlayerClient.h"

LaserProxy::LaserProxy(PlayerClient* p_pClient, unsigned short p_nIndex, unsigned char p_chAccess)
: ClientProxy(p_pClient, PLAYER_LASER_CODE, p_nIndex, p_chAccess)
{
	m_bIntensity = true;
}

LaserProxy::~LaserProxy()
{

}

int LaserProxy::Configure(short p_nMinAngle, short p_nMaxAngle, 
						  unsigned short p_nResolution, bool p_bIntensity)
{
	if (!m_pClient)
		return -1;
	
	player_laser_config_t config;
	config.subtype = PLAYER_LASER_SET_CONFIG;
	config.min_angle = htons(p_nMinAngle);
	config.max_angle = htons(p_nMaxAngle);
	config.resolution = htons(p_nResolution);
	config.intensity = p_bIntensity ? 1 : 0;

	// Copy the values locally
	m_nMaxAngle = p_nMaxAngle;
	m_nMinAngle = p_nMinAngle;
	m_nResolution = p_nResolution;
	
	return m_pClient->Request(PLAYER_LASER_CODE, GetIndex(), (const char*)&config, sizeof(config));
}

int LaserProxy::GetConfigure()
{
	if (!m_pClient)
		return -1;

	player_laser_config_t config;
	player_msghdr_t hdr;

	config.subtype = PLAYER_LASER_GET_CONFIG;

	if (m_pClient->Request(PLAYER_LASER_CODE, GetIndex(),
		(const char*)&config, sizeof(config.subtype),
		&hdr, (char*)&config, sizeof(config)) < 0)
		return(-1);

	m_nMinAngle = ntohs(config.min_angle);
	m_nMaxAngle = ntohs(config.max_angle);
	m_nResolution = ntohs(config.resolution);
	m_bIntensity = config.intensity != 0;
	return 0;
}
void LaserProxy::FillData(player_msghdr_t hdr, const char* buffer)
{
	if (hdr.size != sizeof(player_laser_data_t))
		return;

	player_laser_data_t* msg = (player_laser_data_t*)buffer;

	m_nMinAngle = ntohs(msg->min_angle);
	m_nMaxAngle = ntohs(msg->max_angle);
	m_nResolution = ntohs(msg->resolution);
	m_nRangeCount = ntohs(msg->range_count);

	// Sanity check, to keep things in bounds
	if (m_nRangeCount > PLAYER_LASER_MAX_SAMPLES)
		m_nRangeCount = PLAYER_LASER_MAX_SAMPLES;
	
	memset(m_arrRanges,0,sizeof(m_arrRanges));
	memset(m_arrIntensities,0,sizeof(m_arrIntensities));
	m_nMinLeft = 10000;
	m_nMinRight = 10000;
	for (unsigned short nIndex = 0; nIndex < m_nRangeCount; nIndex++)
	{
		m_arrRanges[nIndex] = ntohs(msg->ranges[nIndex]);

		m_arrIntensities[nIndex] = msg->intensity[nIndex];
		
		if (nIndex > (m_nRangeCount / 2) && m_arrRanges[nIndex] < m_nMinLeft)
			m_nMinLeft = m_arrRanges[nIndex];
		else if (nIndex < (m_nRangeCount / 2) && m_arrRanges[nIndex] < m_nMinRight)
			m_nMinRight = m_arrRanges[nIndex];
	}
}

unsigned short LaserProxy::GetRange(unsigned int p_nIndex) const
{
	if (p_nIndex >= PLAYER_LASER_MAX_SAMPLES)
		return 0;

	return m_arrRanges[p_nIndex];
}

unsigned char LaserProxy::GetIntensity(unsigned int p_nIndex) const
{
	if (p_nIndex >= PLAYER_LASER_MAX_SAMPLES)
		return 0;

	return m_arrIntensities[p_nIndex];
}

// interface that all proxies SHOULD provide
void LaserProxy::Print()
{
	printf("#Laser(%d:%d) - %c\n", GetDevice(), GetIndex(), GetAccess());
	puts("#min\tmax\tres\tcount");
	printf("%d\t%d\t%u\t%u\n", GetMinAngle(), GetMaxAngle(), m_nResolution, m_nRangeCount);
	puts("#range\tintensity");
	for (unsigned short nIndex = 0; nIndex < m_nRangeCount && nIndex < PLAYER_LASER_MAX_SAMPLES; nIndex++)
		printf("%u %u\n", m_arrRanges[nIndex], m_arrIntensities[nIndex]);
}

