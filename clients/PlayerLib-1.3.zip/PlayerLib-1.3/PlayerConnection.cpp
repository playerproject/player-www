// PlayerLib - A Win32 client library for Player
// Copyright (C) 2001,2002
//    Jason K. Douglas, Applied Research Labs, Penn State University
//
//
// Based entirely on:
//   Player - One Hell of a Robot Server
//   Copyright (C) 2000  
//      Brian Gerkey, Kasper Stoy, Richard Vaughan, & Andrew Howard
//                     
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
///////////////////////////////////////


#include "PlayerConnection.h"

PlayerConnection::PlayerConnection()
{
	static bool s_bStartup = false;
	if (!s_bStartup)
	{
		s_bStartup = true;
		WSADATA WSAData;
		int nReturn = WSAStartup (MAKEWORD(1,1), &WSAData);
//		if (nReturn != 0)
			// "ERROR: failed to initialize Windows Sockets 1.1";
	}

	strcpy(m_strBanner,"");
	m_hSocket = INVALID_SOCKET;
}

PlayerConnection::~PlayerConnection()
{

}


int PlayerConnection::Connect(const char* p_strHostname, int p_nPort)
{
	unsigned long nIp;

	Disconnect();

	m_hSocket = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (m_hSocket == INVALID_SOCKET)
		return -1;

	if ((*p_strHostname <= '9') && (*p_strHostname >= '0'))
	{
		if ((nIp = inet_addr(p_strHostname)) == INADDR_NONE)
		{
			Disconnect();
			return -1;
		}
	}
	else
	{
		hostent* pEnt = gethostbyname(p_strHostname);
		if (!pEnt)
		{
			Disconnect();
			return -1;
		}
		nIp = *(unsigned long*)(pEnt->h_addr);
	}

	m_inSockAddr.sin_family = PF_INET;
	m_inSockAddr.sin_port = htons(p_nPort);
	m_inSockAddr.sin_addr = *(in_addr*)&nIp;

	int nRet = connect(m_hSocket, (sockaddr*)&m_inSockAddr, sizeof(sockaddr));
	if (nRet == SOCKET_ERROR)
	{
		Disconnect();
		printf("Failed to connect to Player server (code %ld)\n", WSAGetLastError());
		return -1;
	}

	// Read the banner from the server
	int nNumRead = 0, nNumReadTotal = 0;
	while (nNumReadTotal < PLAYER_IDENT_STRLEN)
	{
		if ((nNumRead = recv(m_hSocket, m_strBanner + nNumReadTotal, PLAYER_IDENT_STRLEN - nNumReadTotal, 0)) < 0)
		{
			Disconnect();

			return -1;
		}

		nNumReadTotal += nNumRead;
	}

	return 0;
}

int PlayerConnection::Disconnect()
{
	if (!IsConnected())
		return 0;

	int nRet = closesocket(m_hSocket);
	m_hSocket = INVALID_SOCKET;
	if (nRet == SOCKET_ERROR)
		return -1;

	return 0;
}

int PlayerConnection::Read(player_msghdr_t *p_nHdr, char *p_strPayload, size_t p_nPayloadLen)
{
	unsigned int nMin = 0;
	unsigned int nReadTotal = 0;
	int nRead = 0;

	char strDummy[PLAYER_MAX_MESSAGE_SIZE];

	if (!IsConnected())
		return -1;

	// Wait for the STX
	p_nHdr->stx = 0;
	while (ntohs(p_nHdr->stx) != PLAYER_STXX)
	{
		nRead = recv(m_hSocket, (char*)&(p_nHdr->stx), sizeof(p_nHdr->stx), 0);
		if (nRead <= 0)
			return -1;
	}
	nReadTotal = nRead;

	// Get the rest of the header
	while (nReadTotal < sizeof(player_msghdr_t))
	{
		nRead = recv(m_hSocket, ((char*)p_nHdr) + nReadTotal, sizeof(player_msghdr_t) - nReadTotal, 0);
		if (nRead <= 0)
			return -1;

		nReadTotal += nRead;
	}

	// Byte-swap as necessary
	p_nHdr->type = ntohs(p_nHdr->type);
	p_nHdr->device = ntohs(p_nHdr->device);
	p_nHdr->device_index = ntohs(p_nHdr->device_index);
	p_nHdr->time_sec = ntohl(p_nHdr->time_sec);
	p_nHdr->time_usec = ntohl(p_nHdr->time_usec);
	p_nHdr->timestamp_sec = ntohl(p_nHdr->timestamp_sec);
	p_nHdr->timestamp_usec = ntohl(p_nHdr->timestamp_usec);
	p_nHdr->size = ntohl(p_nHdr->size);

	// Get the payload
	nMin = min(p_nHdr->size, p_nPayloadLen);

	nReadTotal = 0;
	while (nReadTotal < nMin)
	{
		nRead = recv(m_hSocket, p_strPayload + nReadTotal, nMin - nReadTotal, 0);
		if (nRead <= 0)
		{
			return -1;
		}
		nReadTotal += nRead;
	}

	while (nReadTotal < p_nHdr->size)
	{
		nRead = recv(m_hSocket, strDummy, min(PLAYER_MAX_MESSAGE_SIZE, p_nHdr->size - nReadTotal), 0);
		if (nRead <= 0)
			return -1;

		nReadTotal += nRead;
	}

	return 0;
}

int PlayerConnection::Write(unsigned short p_nDevice, unsigned short p_nIndex,
							const char* p_strCommand, size_t p_nCommandLen,
							int p_nReserved)
{
	// Can't write if you're not connected
	if (!IsConnected())
		return -1;

	char buffer[PLAYER_MAX_MESSAGE_SIZE];
	player_msghdr_t hdr;

	if (p_nCommandLen > PLAYER_MAX_MESSAGE_SIZE - sizeof(player_msghdr_t))
		return -1;

	hdr.stx = htons(PLAYER_STXX);
	hdr.type = htons(PLAYER_MSGTYPE_CMD);
	hdr.device = htons(p_nDevice);
	hdr.device_index = htons(p_nIndex);
	hdr.time_sec = 0;
	hdr.time_usec = 0;
	hdr.timestamp_sec = 0;
	hdr.timestamp_usec = 0;
	hdr.reserved = htonl(p_nReserved);
	hdr.size = htonl((long)p_nCommandLen);

	memcpy(buffer, &hdr, sizeof(player_msghdr_t));
	memcpy(buffer + sizeof(player_msghdr_t), p_strCommand, p_nCommandLen);

	int nRet = send(m_hSocket, buffer, sizeof(player_msghdr_t) + (int)p_nCommandLen, 0);
	if (nRet != (int)(sizeof(player_msghdr_t) + p_nCommandLen))
		return -1;

	return 0;
}

int PlayerConnection::Request(unsigned short p_nDevice, unsigned short p_nIndex,
							  const char *p_strPayload, size_t p_nPayloadLen,
							  player_msghdr_t *p_pReplyHdr, char *p_strReply, size_t p_nReplyLen)
{
	if (!IsConnected())
		return -1;

	char buffer[PLAYER_MAX_MESSAGE_SIZE];
	player_msghdr_t hdr;

	if (p_nPayloadLen > PLAYER_MAX_MESSAGE_SIZE - sizeof(player_msghdr_t))
		return -1;

	hdr.stx = htons(PLAYER_STXX);
	hdr.type = htons(PLAYER_MSGTYPE_REQ);
	hdr.device = htons(p_nDevice);
	hdr.device_index = htons(p_nIndex);
	hdr.time_sec = 0;
	hdr.time_usec = 0;
	hdr.timestamp_sec = 0;
	hdr.timestamp_usec = 0;
	hdr.reserved = 0;
	hdr.size = htonl((long)p_nPayloadLen);
	
	memcpy(buffer, &hdr, sizeof(player_msghdr_t));
	memcpy(buffer + sizeof(player_msghdr_t), p_strPayload, p_nPayloadLen);
	
	int nRet = send(m_hSocket, buffer, sizeof(player_msghdr_t) + (int)p_nPayloadLen, 0);
	if (nRet != (int)(sizeof(player_msghdr_t) + p_nPayloadLen))
		return -1;
	
	// Eat data until the response comes back
	memset(&hdr, 0, sizeof(hdr));
	while (hdr.type != PLAYER_MSGTYPE_RESP_ACK ||
		   hdr.device != p_nDevice ||
		   hdr.device_index != p_nIndex)
	{
		if (Read(&hdr, buffer, sizeof(buffer)))
			return -1;
	}

	// If a reply is wanted, return the message
	if (p_pReplyHdr && p_strReply && p_nReplyLen >= hdr.size)
	{
		*p_pReplyHdr = hdr;
		memcpy(p_strReply, buffer, hdr.size);
		p_nReplyLen = hdr.size;
	}

	return 0;
}

int PlayerConnection::RequestDeviceAccess(unsigned short p_nDevice,
                        unsigned short p_nIndex,
                        unsigned char p_chReqAccess,
                        unsigned char* p_chGrantAccess,
                        char* p_strDriverName,
                        int p_nDriverNameLength)
{
	player_device_req_t req;
	req.subtype = htons(PLAYER_PLAYER_DEV_REQ);
	req.code = htons(p_nDevice);
	req.index = htons(p_nIndex);
	req.access = p_chReqAccess;

	char payload[sizeof(req)];
	memcpy(payload, &req, sizeof(req));

	player_msghdr_t replyHdr;
	char replyBuffer[PLAYER_MAX_MESSAGE_SIZE];
	int nRet = Request(PLAYER_PLAYER_CODE, 0, payload, sizeof(payload), &replyHdr, replyBuffer, sizeof(replyBuffer));
	if (nRet == -1)
		return -1;

	player_device_resp_t response;
	memcpy(&response, replyBuffer, sizeof(response));

	if (p_chGrantAccess != NULL)
		*p_chGrantAccess = response.access;

	if (p_strDriverName != NULL)
		strncpy(p_strDriverName, (LPCSTR)response.driver_name, p_nDriverNameLength);

	return 0;
}
